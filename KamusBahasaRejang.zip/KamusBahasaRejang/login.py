strings = ["a", "ab", "aa", "c"]
strins = ["g", "gb", "gg", "cg"]
new_strings = []
a = input("eh: ")

if a in strings:
    for string in strings:
        new_string = string.replace(strings[len(a)], strins[len(a)])

        new_strings.append(new_string)
        print(len(a))

#print(new_strings)