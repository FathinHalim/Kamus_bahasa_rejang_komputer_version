from kivy.app import App
from kivy.clock import Clock
from kivy.graphics.vertex_instructions import Rectangle
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.label import Label


class TestApp(App):
    def build(self):
        theRoot = FloatLayout()

        # draw the background
        with theRoot.canvas:
            self.rect = Rectangle(source='kaligraf.jpg')

        # use binding to insure that the background stay matched to theRoot
        theRoot.bind(on_size=self.update)
        theRoot.add_widget(Label(text="Hi", size_hint=(None, None), size=(100, 50), pos=(100,100)))

        # need to call update() to get background sized correctly at start
        Clock.schedule_once(self.update, -1)
        return theRoot

    def update(self, *args):
        # set the size and position of the background image
        self.rect.size = self.root.size
        self.rect.pos = self.root.pos


TestApp().run()