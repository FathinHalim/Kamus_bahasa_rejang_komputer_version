import random
while True:
    b = random.randrange(1, 9)
    a =input("number is: ")
    try:
        if int(a) == b:
            print("benar!!")
            break
        else:
            print("coba lagi")
    except ValueError:
        print("masukan nomor!!")