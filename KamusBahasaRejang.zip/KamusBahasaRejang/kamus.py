'''import'''
from kivy.app import App
from kivy.core import window
from kivy.uix.label import Label
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button
from kivy.uix.screenmanager import CardTransition, ScreenManager, Screen, FadeTransition, SlideTransition, FallOutTransition
from kivy.app import App#Import
from kivy.uix.button import Button#Import
from kivy.lang import builder#Import
from kivy.uix.textinput import TextInput#Import
from kivy.uix.gridlayout import GridLayout#Import
from kivy.uix.label import Label#Import
from kivy.core.window import Keyboard, Window#Import
from kivy.uix.widget import Widget#Import
from kivy.uix.image import Image#Import
from kivy.config import Config#Import
from kivy.uix.floatlayout import FloatLayout #Import
from kivy.app import App#import
from kivy.uix.image import AsyncImage#import
from kivy.loader import Loader#import
from kivy.graphics.vertex_instructions import Rectangle
from kivy.clock import Clock
from kivy.config import Config
from kivy.uix.scrollview import ScrollView
from kivy.properties import StringProperty
from kivy.clock import Clock
from kivy.uix.popup import Popup
import random
Window.softinput_mode = "below_target"
'''translate screen'''
class Kamus(GridLayout):
    def __init__(self, **kwargs):
        super(Kamus, self).__init__(**kwargs)
        self.rows = 3
        self.icon = 'aset/a.png'#icon
        self.background_normal = 'aset/apple.png'
        
        self.label = Label(text='Arti Muncul Disini')
        self.rlabel = Label(text='kgf', font_size=60, font_name="aset/Bangkahulu.ttf")
        self.value = TextInput(hint_text="Taruh Kata Disini",multiline=False,background_normal='rejang ke indo_up')#Text input
        self.b4 = Button(text="Mode = Translate", background_normal='aset/apple.png', bold=True, background_down='aset/apple (2).png',on_press=self.ganti_mode)
        self.babel = Button(text='Bahasa: Indonesia ke Rejang',on_press=self.submit2, background_normal='aset/apple.png', bold=True, background_down='aset/apple (2).png')#rejang-indo
        label2 = Image(source="aset/ms.png")#101010100101010100101 hahaha label created by fathina
        self.b5 = Button(text="Kamus Manual", background_normal='aset/apple.png', bold=True, background_down='aset/apple (2).png')

        #================================================================================================

        self.MainGrid = GridLayout()

        with self.MainGrid.canvas:
            self.rect = Rectangle(source='aset/kaligrafi.jpg')
        self.MainGrid.bind(pos=self.update, size=self.update)
        self.MainGrid.bind(on_size=self.update)
        Clock.schedule_once(self.update, -1)

        self.MainGrid.cols = 1
        self.MainGrid.padding = 10
        self.MainGrid.spacing = 10

        self.MainGrid.add_widget(self.value)
        self.MainGrid.add_widget(self.b4)
        self.MainGrid.add_widget(self.babel)
        self.MainGrid.add_widget(self.label)
        self.MainGrid.add_widget(self.rlabel)

        self.add_widget(self.MainGrid)
        self.rejang = False
        self.dialek = 'Lebong'
        self.kaganga_mode = False
        self.value.bind(text=self.submit)

    def ganti_mode(self,_):
        if self.kaganga_mode == True:
            self.kaganga_mode = False
            self.b4.text = "Mode = Translate"
            self.MainGrid.remove_widget(self.value)
            self.MainGrid.remove_widget(self.b4)
            self.MainGrid.remove_widget(self.babel)
            self.MainGrid.remove_widget(self.label)
            self.MainGrid.remove_widget(self.rlabel)
            with self.MainGrid.canvas:
                self.rect = Rectangle(source='aset/kaligrafi.jpg')
            self.MainGrid.bind(pos=self.update, size=self.update)
            self.MainGrid.bind(on_size=self.update)
            Clock.schedule_once(self.update, -1)
            self.MainGrid.add_widget(self.value)
            self.MainGrid.add_widget(self.b4)
            self.MainGrid.add_widget(self.babel)
            self.MainGrid.add_widget(self.label)
            self.MainGrid.add_widget(self.rlabel)
        else:
            self.kaganga_mode = True
            self.b4.text = "Mode = Kaganga"
            self.MainGrid.remove_widget(self.value)
            self.MainGrid.remove_widget(self.b4)
            self.MainGrid.remove_widget(self.babel)
            self.MainGrid.remove_widget(self.label)
            self.MainGrid.remove_widget(self.rlabel)
            with self.MainGrid.canvas:
                self.rect = Rectangle(source='aset/kaligrafi (copy).jpg')
            self.MainGrid.bind(pos=self.update, size=self.update)
            self.MainGrid.add_widget(self.value)
            self.MainGrid.add_widget(self.b4)
            self.MainGrid.add_widget(self.label)
            self.MainGrid.add_widget(self.rlabel)
            self.MainGrid.bind(on_size=self.update)
            Clock.schedule_once(self.update, -1)
    def update(self, *args):
        # set the size and position of the background image
        self.rect.size = Window.size
        self.rect.pos = self.pos
    def submit2(self, obj):
            self.value.text = ''
            if self.rejang == True:
                    self.rejang = False
                    self.babel.text = 'Bahasa: Indonesia ke Rejang'
            else:
                self.rejang = True
                self.babel.text = 'Bahasa: Rejang ke Indonesia'
            print(self.rejang)
    def submit(self, instance, text):#def jika tombol indonesia ke rejang ditekan#
            self.label.text = self.value.text
            a = self.value.text     
            a = str(self.value.text)
            a = a.lower()
            self.value.text = a
            if self.value.text == "":
                a = "Arti Muncul Disini"
            if self.kaganga_mode == False:

                if self.rejang == False:
                        if "baju" in self.label.text:
                            a = a.replace("baju", '')
                            a += "keracok "

                        if "cahaya" in self.label.text:
                            a = a.replace("cahaya", '')
                            a += "cayo "

                        if "terang" in self.label.text:
                            a = a.replace("terang", '')
                            a += "tê'ang "

                        if "senja" in self.label.text:
                            a = a.replace("senja", '')
                            a += "sinjo "

                        if "jelek" in self.label.text:
                            a = a.replace("jelek", '')
                            a += "kidek "

                        if "buruk" in self.label.text:
                            a = a.replace("buruk", '')
                            a += "kidek "

                        if "kamar" in self.label.text:
                            a = a.replace("kamar", '')
                            a += "bilik "

                        if "beranda" in self.label.text:
                            a = a.replace("beranda", '')
                            a += "berendo "

                        if "halaman" in self.label.text:
                            a = a.replace("halaman", '')
                            b = ["danet ", "natet "]
                            a += random.choice(b)

                        if "teras" in self.label.text:
                            a = a.replace("teras", '')
                            a += "danea "

                        if "uang" in self.label.text:
                            a = a.replace("uang", '')
                            a += "caci "

                        if "ini"in self.label.text:
                            if not "ke sini" in self.label.text and "kesini" in self.label.text:
                                a = a.replace("kes ini", '')
                                a += "dio "
        
                        if "itu"in self.label.text:
                            a += "do'o "
                        if "kamu" in self.label.text:
                            a = a.replace("kamu", '')
                            b = ["ko ", "kumu "]
                            a += random.choice(b)

                        if "anda" in self.label.text:
                            a = a.replace("anda", '')
                            a += "kumu "

                        if "desa" in self.label.text:
                            a = a.replace("desa", '')
                            a += "sadei "

                        if "aku"in self.label.text:
                            a = a.replace("aku", 'uku ')

                        elif "saya" in self.label. text:
                            a = a.replace("saya", 'uku ')

                        elif "ku" in self.label.text:
                            if not "aku" in self.label.text:
                                a = a.replace("ku", 'uku ')
        
                        if "suka" in self.label.text:
                            a = a.replace("suka", '')
                            a += "galak "

                        if "mau"in self.label.text:
                            a += "lok "
                        if "makan" in self.label.text:
                            a = a.replace("makan", '')
                            b = ["mbu ", "mukmei "]
                            a += random.choice(b)

                        if "nasi" in self.label.text:
                            a = a.replace("nasi", '')
                            a += "mei "

                        if "padi" in self.label.text:
                            a = a.replace("padi", '')
                            a += "poi "

                        if "bunga" in self.label.text:
                            if "bunga bangkai" in self.label.text:
                                a = a.replace("bunga bangkai", '')
                                a += "kibut "
        
                            elif "bunga rafflesia" in self.label.text:
                                a = a.replace("bunga rafflesia", '')
                                a += "skedei "
        
                            else:
                                a = a.replace("bunga", '')
                                a += "bungei "
        
                        if "nikah" in self.label.text:
                            a = a.replace("nikah", '')
                            a += "nikeak  "

                        if "siapa" in self.label.text:
                            a = a.replace("siapa", '')
                            a += "api "

                        if "nama" in self.label.text:
                            a = a.replace("nama", '')
                            a += "gen "

                        if "jangan" in self.label.text:
                            a = a.replace("jangan", '')
                            a += "jibeak "

                        if "tabrak" in self.label.text:
                            a = a.replace("tabrak", '')
                            a += "tumbua "

                        if "darat" in self.label.text:
                            a = a.replace("darat", '')
                            a += "da'et "

                        if "datar" in self.label.text:
                            a = a.replace("datar", '')
                            a += "datea "

                        if "gunung" in self.label.text:
                            a = a.replace("gunung", '')
                            a += "tebo "

                        if "danau" in self.label.text:
                            a = a.replace("danau", '')
                            a += "tebo "

                        if "kira-kira" in self.label.text:
                            a = a.replace("kira-kira", '')
                            a += "abeak "

                        if "habis" in self.label.text:
                            a = a.replace("habis", '')
                            a += "abis "

                        if "kebiasaan" in self.label.text:
                            a = a.replace("kebiasaan", '')
                            a += "adat "

                        if "ada"in self.label.text:
                            a += "ade "
                        if "mempunyai" in self.label.text:
                            a = a.replace("mempunyai", '')
                            a += "ade "

                        if "agak" in self.label.text:
                            a = a.replace("agak", '')
                            a += "agak "

                        if "cantik" in self.label.text:
                            a = a.replace("cantik", '')
                            a += "alep "

                        if "pergi" in self.label.text:
                            a = a.replace("pergi", '')
                            a += "aleu "

                        if "masuk hutan" in self.label.text:
                            a = a.replace("masuk hutan", '')
                            a += "aleu mai beak im'o "

                        if "pergi jalan jalan" in self.label.text:
                            a = a.replace("jalan jalan", '')
                            a += "aleu mai meto "

                        if "jika" in self.label.text:
                            a = a.replace("jika", '')
                            a += "amen "

                        if "jangan" in self.label.text:
                            a = a.replace("jangan", '')
                            a += "ami "

                        if "mungkin" in self.label.text:
                            a = a.replace("mungkin", '')
                            a += "ami "

                        if "lama kelamaan" in self.label.text:
                            a = a.replace("lama kelamaan", '')
                            a += "an-an "

                        if "anak" in self.label.text:
                            a = a.replace("anak", '')
                            a += "anak/anok "

                        if "anak buah" in self.label.text:
                            a = a.replace("anak buah", '')
                            a += "anak bueak/anok bueak "

                        if "anak panah" in self.label.text:
                            a = a.replace("anak panah", '')
                            a += "anak pana/anok pana "

                        if "anak kesayangan" in self.label.text:
                            a = a.replace("anak kesayangan", '')
                            a += "anak sayang/anok sayang "

                        if "lama kelamaan" in self.label.text:
                            a = a.replace("lama kelamaan", '')
                            a += "an-an "

                        if "angggar" in self.label.text:
                            a = a.replace("angggar", '')
                            a += "ang'ar "

                        if "angan angan" in self.label.text:
                            a = a.replace("angan angan", '')
                            a += "ang'en "

                        if "angin" in self.label.text:
                            a = a.replace("angin", '')
                            a += "angin-angin "

                        if "haram" in self.label.text:
                            a = a.replace("haram", '')
                            a += "apang "

                        if "hampa" in self.label.text:
                            a = a.replace("hampa", '')
                            a += "apei "

                        if "siapa saja" in self.label.text:
                            a = a.replace("siapa saja", '')
                            a += "api bai "

                        if "berbagai" in self.label.text:
                            a = a.replace("berbagai", '')
                            a += "areak "

                        if "banyak pakaian" in self.label.text:
                            a = a.replace("banyak pakaian", '')
                            a += "areak keracok "

                        if "agak" in self.label.text:
                            a = a.replace("agak", '')
                            a += "arung "

                        if "harus" in self.label.text:
                            a = a.replace("harus", '')
                            a += "arus "

                        if "seharusnya" in self.label.text:
                            a = a.replace("seharusnya", '')
                            a += "arus "

                        if "asal" in self.label.text:
                            a = a.replace("asal", '')
                            a += "asal "

                        if "asal usul" in self.label.text:
                            a = a.replace("asal usul", '')
                            a += "asal usul "

                        if "rasa" in self.label.text:
                            a = a.replace("rasa", '')
                            a += "asei "

                        if "menurut saya" in self.label.text:
                            a = a.replace("menurut saya", '')
                            a += "asei ku "

                        if "akan" in self.label.text:
                            a = a.replace("akan", '')
                            if not "makan" in self.label.text:
                                a = a.replace("makan", '')
                                a += "asei asei "
        
                        if "adik" in self.label.text:
                            a = a.replace("adik", '')
                            a += "asoak "

                        if "adek" in self.label.text:
                            a = a.replace("adek", '')
                            a += "asoak "

                        if "atau" in self.label.text:
                            a = a.replace("atau", '')
                            a += "atau "

                        if "atap" in self.label.text:
                            a = a.replace("atap", '')
                            a += "atep "

                        if "belum" in self.label.text:
                            a = a.replace("belum", '')
                            a += "ati "

                        if "belum waktunya" in self.label.text:
                            a = a.replace("belum waktunya", '')
                            a += "ati si eng'ut "

                        if "hati" in self.label.text:
                            a = a.replace("hati", '')
                            a += "atie "

                        if "giliran" in self.label.text:
                            a = a.replace("giliran", '')
                            a += "aturan "

                        if "ya"in self.label.text:
                            if not "saya" in self.label.text:
                            
                                self.label.text += "au "
                        if "badan" in self.label.text:
                            a = a.replace("badan", '')
                            a += "awak"

                        if "seperti" in self.label.text:
                            a = a.replace("seperti", '')
                            a += "awie "

                        if "demikian" in self.label.text:
                            a = a.replace("demikian", '')
                            a += "awie o "

                        if "serin" in self.label.text:
                            a = a.replace("serin", '')
                            a += "awit "

                        if "sebelum" in self.label.text:
                            a = a.replace("sebelum", '')
                            a += "awit "

                        if "adalah" in self.label.text:
                            a = a.replace("adalah", '')
                            a += "ayak "

                            self.label.text += self.value.text
                        if "pembantu" in self.label.text:
                            a = a.replace("pembantu", '')
                            a += "babu "

                        if "bagus" in self.label.text:
                            a = a.replace("bagus", '')
                            a += "ba'es "

                        if "indah" in self.label.text:
                            a = a.replace("indah", '')
                            a += "ba'es-ba'es ne "

                        if "nasib" in self.label.text:
                            a = a.replace("nasib", '')
                            a += "bagei "

                        if "bahaya" in self.label.text:
                            a = a.replace("bahaya", '')
                            a += "bahayo "

                        if "saja" in self.label.text:
                            a = a.replace("saja", '')
                            a += "baei "

                        if "enak" in self.label.text:
                            a = a.replace("enak", '')
                            a += "baik "

                        if "terhomat" in self.label.text:
                            a = a.replace("terhomat", '')
                            a += "baik-baik "

                        if "ayah" in self.label.text:
                            a = a.replace("ayah", '')
                            a += "bak"

                        if "musibah" in self.label.text:
                            a = a.replace("musibah", '')
                            a += "balak"

                        if "balas" in self.label.text:
                            a = a.replace("balas", '')
                            a += "bales "

                        if "beran" in self.label.text:
                            a = a.replace("beran", '')
                            a += "banak"

                        if "bangsa" in self.label.text:
                            a = a.replace("bangsa", '')
                            a += "bangso"

                        if "seperti" in self.label.text:
                            a = a.replace("seperti", '')
                            a += "barat "

                        if "bersaudara" in self.label.text:
                            a = a.replace("bersaudara", '')
                            a += "basoak "

                        if "nanti" in self.label.text:
                            a = a.replace("nanti", '')
                            a += "be "

                        if "bawah" in self.label.text:
                            a = a.replace("bawah", '')
                            a += "beak "

                        if "berayah" in self.label.text:
                            a = a.replace("berayah", '')
                            a += "bebak "

                        if "bercabang" in self.label.text:
                            a = a.replace("bercabang", '')
                            a += "becabang "

                        if "kicau" in self.label.text:
                            a = a.replace("kicau", '')
                            a += "beceneu "

                        if "bercerai" in self.label.text:
                            a = a.replace("bercerai", '')
                            a += "beci'ie/beci ie "

                        if "berdua" in self.label.text:
                            a = a.replace("berdua", '')
                            a += "beduei "

                        if "berat" in self.label.text:
                            a = a.replace("berat", '')
                            a += "be'et "

                        if "memanggil ibu kepada" in self.label.text:
                            a = a.replace("ibu kepada", '')
                            a += "bein'ok "

                        if "luar biasa" in self.label.text:
                            a = a.replace("luar biasa", '')
                            a += "bejako "

                        if "menjadi" in self.label.text:
                            a = a.replace("menjadi", '')
                            a += "bejijei "

                        if "berkerja" in self.label.text:
                            a = a.replace("berkerja", '')
                            a += "bekakok "

                        if "berbuah" in self.label.text:
                            a = a.replace("berbuah", '')
                            a += "bekboak "

                        if "memanjat" in self.label.text:
                            a = a.replace("memanjat", '')
                            a += "bekenek "

                        if "mencari" in self.label.text:
                            a = a.replace("mencari", '')
                            a += "bekesoa "

                        if "belakang" in self.label.text:
                            a = a.replace("belakang", '')
                            a += "belakang "

                        if "beras" in self.label.text:
                            a = a.replace("beras", '')
                            a += "belas "

                        if "berbaris" in self.label.text:
                            a = a.replace("berbaris", '')
                            a += "bele'et/bele et "

                        if "pulan" in self.label.text:
                            a = a.replace("pulan", '')
                            a += "belek "

                        if "hidup kembali" in self.label.text:
                            a = a.replace("hidup kembali", '')
                            a += "belek idup "

                        if "dulu" in self.label.text:
                            a = a.replace("dulu", '')
                            a += "bele o "

                        if "melahirkan" in self.label.text:
                            a = a.replace("melahirkan", '')
                            a += "belpas "

                        if "dibiarkan bebas" in self.label.text:
                            a = a.replace("dibiarkan bebas", '')
                            a += "belpas/nelpas "

                        if "benan" in self.label.text:
                            a = a.replace("benan", '')
                            a += "benang "

                        if "binatang" in self.label.text:
                            a = a.replace("binatang", '')
                            a += "benatang "

                        if "mengapa" in self.label.text:
                            a = a.replace("mengapa", '')
                            a += "bene "

                        if "memangil nenek kepada" in self.label.text:
                            a = a.replace("nenek kepada", '')
                            a += "beninik "

                        if "berjalan" in self.label.text:
                            a = a.replace("berjalan", '')
                            a += "bepanuo "

                        if "berpikir" in self.label.text:
                            a = a.replace("berpikir", '')
                            a += "bepeker "

                        if "menyanyi" in self.label.text:
                            a = a.replace("menyanyi", '')
                            a += "berjung "

                        if "bersama" in self.label.text:
                            a = a.replace("bersama", '')
                            a += "berpak "

                        if "saja" in self.label.text:
                            a = a.replace("saja", '')
                            a += "besi "

                        if "silat" in self.label.text:
                            a = a.replace("silat", '')
                            a += "besilek "

                        if "bertaut" in self.label.text:
                            a = a.replace("bertaut", '')
                            a += "betakup "

                        if "bertanding" in self.label.text:
                            a = a.replace("bertanding", '')
                            a += "betan ing/betan'ing "

                        if "sudah" in self.label.text:
                            a = a.replace("sudah", '')
                            a += "bi "

                        if "dewasa" in self.label.text:
                            a = a.replace("dewasa", '')
                            a += "bi lei "

                        if "biasa" in self.label.text:
                            a = a.replace("biasa", '')
                            a += "biaso"

                        if "perempuan" in self.label.text:
                            a = a.replace("perempuan", '')
                            a += "bie "

                        if "hari" in self.label.text:
                            a = a.replace("hari", '')
                            a += "bilei "

                        if "sepanjang hari" in self.label.text:
                            a = a.replace("sepanjang hari", '')
                            a += "bilei bilei/bilei-bilei "

                        if "beranian" in self.label.text:
                            a = a.replace("beranian", '')
                            a += "binei "

                        if "air"in self.label.text:
                            a = a.replace("air","bioa")
                            a += "bioa "
                        if "sungai" in self.label.text:
                            a = a.replace("sungai", '')
                            a += "bioa "

                        if "beris" in self.label.text:
                            a = a.replace("beris", '')
                            a += "bisei "

                        if "memuat" in self.label.text:
                            a = a.replace("memuat", '')
                            a += "bisei "

                        if "buah" in self.label.text:
                            a = a.replace("buah", '')
                            a += "boak "

                        if "buah buahan" in self.label.text:
                            a = a.replace("buah buahan", '')
                            a += "boak boak/boak-boak "

                        if "buah-buahan" in self.label.text:
                            a = a.replace("buah-buahan", '')
                            a += "boak boak/boak-boak "

                        if "bambu" in self.label.text:
                            a = a.replace("bambu", '')
                            a += "boloak "

                        if "buas" in self.label.text:
                            a = a.replace("buas", '')
                            a += "buas "

                        if "bangkai" in self.label.text:
                            a = a.replace("bangkai", '')
                            a += "bukie "

                        if "berhasil" in self.label.text:
                            a = a.replace("berhasil", '')
                            a += "buleak"

                        if "boleh" in self.label.text:
                            a = a.replace("boleh", '')
                            a += "buleak"

                        if "patun" in self.label.text:
                            a = a.replace("patun", '')
                            a += "buteu "

                        if "batu" in self.label.text:
                            a = a.replace("batu", '')
                            a += "buteu "

                        if "batal" in self.label.text:
                            a = a.replace("batal", '')
                            a += "buye "

                        if "buyun" in self.label.text:
                            a = a.replace("buyun", '')
                            a += "buyung "

                        if "cara" in self.label.text:
                            a = a.replace("cara", '')
                            a += "ca'o/ca o "

                        if "celaka" in self.label.text:
                            a = a.replace("celaka", '')
                            a += "celako "

                        if "bermacam macam" in self.label.text:
                            a = a.replace("bermacam macam", '')
                            a += "cem cem/cem-cem "

                        if "menyirami" in self.label.text:
                            a = a.replace("menyirami", '')
                            a += "cemim'ie/cemim ie "

                        if "mencoba" in self.label.text:
                            a = a.replace("mencoba", '')
                            a += "cemubo "

                        if "tercengang" in self.label.text:
                            a = a.replace("tercengang", '')
                            a += "cengang "

                        if "dicoba" in self.label.text:
                            a = a.replace("dicoba", '')
                            a += "cenubo "

                        if "disiram" in self.label.text:
                            a = a.replace("disiram", '')
                            a += "cenu'ie/cenu ie "

                        if "alkisah" in self.label.text:
                            a = a.replace("alkisah", '')
                            a += "cerito "

                        if "tidak lagi" in self.label.text:
                            a = a.replace("tidak lagi", '')
                            a += "cigei "

                        if "tidak" in self.label.text:
                            a = a.replace("tidak", '')
                            a += "coa "

                        if "tidak lama berselang" in self.label.text:
                            a = a.replace("lama berselang", '')
                            a += "coa an udo o "

                        if "tidak ada" in self.label.text:
                            a = a.replace("tidak ada", '')
                            a += "coade(coa ade) "

                        if "bukan main" in self.label.text:
                            a = a.replace("bukan main", '')
                            a += "coa si angen "

                        if "coba" in self.label.text:
                            a = a.replace("coba", '')
                            a += "cubo "

                        if "manja" in self.label.text:
                            a = a.replace("manja", '')
                            a += "cuik "

                        if "cuka" in self.label.text:
                            a = a.replace("cuka", '')
                            a += "cuko "

                        if "cukup" in self.label.text:
                            a = a.replace("cukup", '')
                            a += "cukup "

                        if "hanya" in self.label.text:
                            a = a.replace("hanya", '')
                            a += "cuma "

                        if "cuman" in self.label.text:
                            a = a.replace("cuman", '')
                            a += "cuma "

                        if "berdampingan" in self.label.text:
                            a = a.replace("berdampingan", '')
                            a += "cupek "

                        if "bayi" in self.label.text:
                            a = a.replace("bayi", '')
                            a += "cupik "

                        if "dagin" in self.label.text:
                            a = a.replace("dagin", '')
                            a += "daging "

                        if "darah" in self.label.text:
                            a = a.replace("darah", '')
                            a += "daleak "

                        if "jalan" in self.label.text:
                            a = a.replace("jalan", '')
                            a += "dalen "

                        if "jangan" in self.label.text:
                            a = a.replace("jangan", '')
                            a += "dang "

                        if "mendapat" in self.label.text:
                            a = a.replace("mendapat", '')
                            a += "dapet "

                        if "atas" in self.label.text:
                            a = a.replace("atas", '')
                            a += "das "

                        if "dalam rumah" in self.label.text:
                            a = a.replace("dalam rumah", '')
                            a += "dasie "

                        if "daun" in self.label.text:
                            a = a.replace("daun", '')
                            a += "dawen "

                        if "satu hari" in self.label.text:
                            a = a.replace("satu hari", '')
                            a += "debilei(do + bilei) "

                        if "sesaat" in self.label.text:
                            a = a.replace("sesaat", '')
                            a += "decang "

                        if "situ" in self.label.text:
                            a = a.replace("situ", '')
                            a += "dee "

                        if "mirip" in self.label.text:
                            a = a.replace("mirip", '')
                            a += "dekmai "

                        if "cepat" in self.label.text:
                            a = a.replace("cepat", '')
                            a += "delas "

                        if "pedulikan" in self.label.text:
                            a = a.replace("pedulikan", '')
                            a += "demulei "

                        if "didepan" in self.label.text:
                            a = a.replace("didepan", '')
                            a += "denam "

                        if "dulu" in self.label.text:
                            a = a.replace("dulu", '')
                            a += "dete "

                        if "banyak" in self.label.text:
                            a = a.replace("banyak", '')
                            a += "deu "

                        if "sendiri" in self.label.text:
                            a = a.replace("sendiri", '')
                            a += "dewek "

                        if "diri" in self.label.text:
                            a = a.replace("diri", '')
                            a += "dewek "

                        if "yang" in self.label.text:
                            a = a.replace("yang", '')
                            a += "di(di menang) "

                        if "sana" in self.label.text:
                            a = a.replace("sana", '')
                            if not "kesana" in self. value.text and not "ke sana" in self.label.text:
                                a += "di(nak di) "
        
                        if "tertua" in self.label.text:
                            a = a.replace("tertua", '')
                            a += "di tuei suang "

                        if "sedikit" in self.label.text:
                            a = a.replace("sedikit", '')
                            a += "didik "

                        if "diam" in self.label.text:
                            a = a.replace("diam", '')
                            a += "diem "

                        if "tinggal" in self.label.text:
                            a = a.replace("tinggal", '')
                            a += "diem "

                        if "seorang" in self.label.text:
                            a = a.replace("seorang", '')
                            a += "dikup "

                        if "seekor" in self.label.text:
                            a = a.replace("seekor", '')
                            a += "dikup "

                        if "yang mana" in self.label.text:
                            a = a.replace("yang mana", '')
                            a += "dipe "

                        if "yang ini" in self.label.text:
                            a = a.replace("yang ini", '')
                            a += "diye "

                        if "satu" in self.label.text:
                            a = a.replace("satu", '')
                            a += "do "

                        if "jauh ke sana" in self.label.text:
                            a = a.replace("ke sana", '')
                            a += "doloi "

                        if "itulah" in self.label.text:
                            a = a.replace("itulah", '')
                            a += "doo ba "

                        if "dua"in self.label.text:
                            a += "duei "
                        if "keduanya" in self.label.text:
                            a = a.replace("keduanya", '')
                            a += "duei duei/duei-duei "

                        if "rotan" in self.label.text:
                            a = a.replace("rotan", '')
                            a += "ebes "

                        if "rejan" in self.label.text:
                            a = a.replace("rejan", '')
                            a += "ejang "

                        if "perempuan tua" in self.label.text:
                            a = a.replace("perempuan tua", '')
                            a += "em ie/em'ie "

                        if "membawa" in self.label.text:
                            a = a.replace("membawa", '')
                            a += "em in/em'in "

                        if "cepat  cepat" in self.label.text:
                            a = a.replace("cepat  cepat", '')
                            a += "gacang gacang/gacang-gacan g"

                        if "cepat-cepat" in self.label.text:
                            a = a.replace("cepat-cepat", '')
                            a += "gacang gacang/gacang-gaca ng"

                        if "giliran" in self.label.text:
                            a = a.replace("giliran", '')
                            a += "gelea "

                        if "menggantung" in self.label.text:
                            a = a.replace("menggantung", '')
                            a += "gematung "

                        if "mengganti" in self.label.text:
                            a = a.replace("mengganti", '')
                            a += "gemitie "

                        if "menganggu" in self.label.text:
                            a = a.replace("menganggu", '')
                            a += "gemurek"

                        if "untuk apa" in self.label.text:
                            a = a.replace("untuk apa", '')
                            a += "gen jano"

                        if "untuk apa?" in self.label.text:
                            a = a.replace("apa?", '')
                            a += "gen jano? "

                        if "bahan makanan" in self.label.text:
                            a = a.replace("bahan makanan", '')
                            a += "gen kem'uk/gen kem uk"

                        if "digantung" in self.label.text:
                            a = a.replace("digantung", '')
                            a += "genatung "

                        if "diganti" in self.label.text:
                            a = a.replace("diganti", '')
                            a += "genitie "

                        if "puas" in self.label.text:
                            a = a.replace("puas", '')
                            a += "genyei "

                        if "bosan" in self.label.text:
                            a = a.replace("bosan", '')
                            a += "genyei "

                        if "gagah perkasa" in self.label.text:
                            a = a.replace("gagah perkasa", '')
                            a += "gerot "

                        if "untuk" in self.label.text:
                            a = a.replace("untuk", '')
                            a += "gi "

                        if "masih" in self.label.text:
                            a = a.replace("masih", '')
                            a += "gi "

                        if "sedan" in self.label.text:
                            a = a.replace("sedan", '')
                            a += "gidong "

                        if "ganti" in self.label.text:
                            a = a.replace("ganti", '')
                            a += "gitie "

                        if "masalah" in self.label.text:
                            a = a.replace("masalah", '')
                            a += "hai "

                        if "harta" in self.label.text:
                            a = a.replace("harta", '')
                            a += "hak"

                        if "sedih" in self.label.text:
                            a = a.replace("sedih", '')
                            a += "ibo"

                        if "dekat" in self.label.text:
                            a = a.replace("dekat", '')
                            a += "iding "

                        if "hidup" in self.label.text:
                            a = a.replace("hidup", '')
                            a += "idup "

                        if "terlalu" in self.label.text:
                            a = a.replace("terlalu", '')
                            a += "ige "

                        if "lagi" in self.label.text:
                            a = a.replace("lagi", '')
                            a += "igei "

                        if "ilmu" in self.label.text:
                            a = a.replace("ilmu", '')
                            a += "ilmeu "

                        if "harimau" in self.label.text:
                            a = a.replace("harimau", '')
                            a += "imuo "

                        if "ibu"in self.label.text:
                            a = a.replace("ibu", "")
                            a += "in'ok "
                        if "mana" in self.label.text:
                            a = a.replace("mana", '')
                            a += "ipe "

                        if "isi"in self.label.text:
                            if not "disini":
                                a = a.replace("disini", "")
                                a += "isei "
                        if "bukan" in self.label.text:
                            a = a.replace("bukan", '')
                            a += "iso "

                        if "kita" in self.label.text:
                            a = a.replace("kita", '')
                            a += "ite "

                        if "batas" in self.label.text:
                            a = a.replace("batas", '')
                            a += "jako "

                        if "sampa" in self.label.text:
                            a = a.replace("sampa", '')
                            a += "jako "

                        if "jambu" in self.label.text:
                            a = a.replace("jambu", '')
                            a += "jam'eu/jem eu "

                        if "janji" in self.label.text:
                            a = a.replace("janji", '')
                            a += "janjei "

                        if "syarat" in self.label.text:
                            a = a.replace("syarat", '')
                            a += "janjei "  

                        if "apapun" in self.label.text:
                            a = a.replace("apapun", '')
                            a += "jano "  

                        if "apa yang diingininya" in self.label.text:
                            a = a.replace("yang diingininya", '')
                            a += "jano kelak ne "  

                        if "jantung" in self.label.text:
                            a = a.replace("jantung", '')
                            a += "jatung "  

                        if "bendungan" in self.label.text:
                            a = a.replace("bendungan", '')
                            a += "jekung "  

                        if "menjaga" in self.label.text:
                            a = a.replace("menjaga", '')
                            a += "jemago "  

                        if "menjawab" in self.label.text:
                            a = a.replace("menjawab", '')
                            a += "jemawab "  

                        if "menjual" in self.label.text:
                            a = a.replace("menjual", '')
                            a += "jemuoa "  

                        if "benci" in self.label.text:
                            a = a.replace("benci", '')
                            a += "jengik "  

                        if "iri"in self.label.text:
                            a += "jengik " 
                        if "jangan jangan" in self .value.text:
                            a = a.replace("jangan jangan", '')
                            a += "jibeak "  

                        if "jangan-jangan" in self.label.text:
                            a = a.replace("jangan-jangan", '')
                            a += "jibeak "  

                        if "kuburan" in self.label.text:
                            a = a.replace("kuburan", '')
                            a += "ji'et/ji et "  

                        if "jadi" in self.label.text:
                            a = a.replace("jadi", '')
                            a += "jijei "  

                        if "kakak" in self.label.text:
                            a = a.replace("kakak", '')
                            a += "jisanak "  

                        if "bekal" in self.label.text:
                            a = a.replace("bekal", '')
                            a += "juadeak "

                        if "teman" in self.label.text:
                            a = a.replace("teman", '')
                            a += "kaben "  

                        if "rombongan" in self.label.text:
                            a = a.replace("rombongan", '')
                            a += "kaben "  

                        if "kancil" in self.label.text:
                            a = a.replace("kancil", '')
                            a += "kacea "  

                        if "leher" in self.label.text:
                            a = a.replace("leher", '')
                            a += "kagen "  

                        if "kulit" in self.label.text:
                            a = a.replace("kulit", '')
                            a += "kak "  

                        if "pihak" in self.label.text:
                            a = a.replace("pihak", '')
                            a += "kak "  

                        if "pihak sana" in self.label.text:
                            a = a.replace("pihak sana", '')
                            a += "kak di "  

                        if "pihak ini" in self.label.text:
                            a = a.replace("pihak ini", '')
                            a += "kak yo "  

                        if "kerja" in self.label.text:
                            a = a.replace("kerja", '')
                            a += "kakok "  

                        if "kalau" in self.label.text:
                            a = a.replace("kalau", '')
                            a += "kaleu "  

                        if "kambing" in self.label.text:
                            a = a.replace("kambing", '')
                            a += "kam'ing/kam ing "  

                        if "ikan" in self.label.text:
                            a = a.replace("ikan", '')
                            a += "kan "  

                        if "katun" in self.label.text:
                            a = a.replace("katun", '')
                            a += "kapes "  

                        if "lantas" in self.label.text:
                            a = a.replace("lantas", '')
                            a += "kea "  

                        if "alangkah indah" in self.label.text:
                            a = a.replace("alangkah indah", '')
                            a += "keba es/keba'es "  

                        if "kata" in self.label.text:
                            a = a.replace("kata", '')
                            a += "kecek "  

                        if "cepat cepat" in self.label.text:
                            a = a.replace("cepat cepat", '')
                            a += "kedelas "  

                        if "cepat-cepat" in self.label.text:
                            a = a.replace("cepat-cepat", '')
                            a += "kedelas "  

                        if "keperkasaan" in self.label.text:
                            a = a.replace("keperkasaan", '')
                            a += "kegerot "  

                        if "kerin" in self.label.text:
                            a = a.replace("kerin", '')
                            a += "ke ing/ke'ing "  

                        if "kejei" in self.label.text:
                            a = a.replace("kejei", '')
                            a += "kejei "  

                        if "kejadian" in self.label.text:
                            a = a.replace("kejadian", '')
                            a += "kejijei "  

                        if "kaki" in self.label.text:
                            a = a.replace("kaki", '')
                            a += "kekea "  

                        if "keinginan" in self.label.text:
                            a = a.replace("keinginan", '')
                            a += "kelak "  

                        if "cita cita" in self.label.text:
                            a = a.replace("cita cita", '')
                            a += "kelak "  

                        if "cita-cita" in self.label.text:
                            a = a.replace("cita-cita", '')
                            a += "kelak "  

                        if "lihat" in self.label.text:
                            a = a.replace("lihat", '')
                            a += "keleak "  

                        if "sebesar" in self.label.text:
                            a = a.replace("sebesar", '')
                            a += "kelei "  

                        if "sekeliling" in self.label.text:
                            a = a.replace("sekeliling", '')
                            a += "kejijei "  

                        if "suruhlah" in self.label.text:
                            a = a.replace("suruhlah", '')
                            a += "keloak "  

                        if "suruhlah!" in self.label.text:
                            a = a.replace("suruhlah!", '')
                            a += "keloak "  

                        if "kalen" in self.label.text:
                            a = a.replace("kalen", '')
                            a += "kelwang "  

                        if "ambilah" in self.label.text:
                            a = a.replace("ambilah", '')
                            a += "kemak "

                        if "kami" in self.label.text:
                            a = a.replace("kami", '')
                            a += "keme "  

                        if "terlalu" in self.label.text:
                            a = a.replace("terlalu", '')
                            a += "kemelbak "  

                        if "mengerjakan" in self.label.text:
                            a = a.replace("mengerjakan", '')
                            a += "kemerjo "  

                        if "pedulikan" in self.label.text:
                            a = a.replace("pedulikan", '')
                            a += "kemian "  

                        if "bawalah" in self.label.text:
                            a = a.replace("bawalah", '')
                            a += "kem in/kem'in "  

                        if "ambilah" in self.label.text:
                            a = a.replace("ambilah", '')
                            a += "kem in/kem'in "  

                        if "menguburkan" in self.label.text:
                            a = a.replace("menguburkan", '')
                            a += "kemoboa "  

                        if "memperlihatkan" in self.label.text:
                            a = a.replace("memperlihatkan", '')
                            a += "kemten "  

                        if "dibuka" in self.label.text:
                            a = a.replace("dibuka", '')
                            a += "ken'ak/ken ak "  

                        if "dilihat" in self.label.text:
                            a = a.replace("dilihat", '')
                            a += "keleak "  

                        if "dikuburkan" in self.label.text:
                            a = a.replace("dikuburkan", '')
                            a += "kenoboa "    

                        if "keterampilan" in self.label.text:
                            a = a.replace("keterampilan", '')
                            a += "kepacak "  

                        if "keahlian" in self.label.text:
                            a = a.replace("keahlian", '')
                            a += "kepacak "  

                        if "perangilah" in self.label.text:
                            a = a.replace("perangilah", '')
                            a += "kerang ba "  

                        if "karena" in self.label.text:
                            a = a.replace("karena", '')
                            a += "kerno "  

                        if "masak" in self.label.text:
                            a = a.replace("masak", '')
                            a += "kesak "  

                        if "aneh sekali" in self.label.text:
                            a = a.replace("aneh sekali", '')
                            a += "kesele "  

                        if "semua" in self.label.text:
                            a = a.replace("semua", '')
                            a += "kete "  

                        if "kelihatan" in self.label.text:
                            a = a.replace("kelihatan", '')
                            a += "keten "  

                        if "yang ketiga" in self.label.text:
                            a = a.replace("yang ketiga", '')
                            a += "ketleu "  

                        if "kurun" in self.label.text:
                            a = a.replace("kurun", '')
                            a += "ke ung "  

                        if "nantinya" in self.label.text:
                            a = a.replace("nantinya", '')
                            a += "ke ung "  

                        if "mohon" in self.label.text:
                            a = a.replace("mohon", '')
                            a += "kinai "  

                        if "teringat" in self.label.text:
                            a = a.replace("teringat", '')
                            a += "kinget "  

                        if "sekitar sini" in self.label.text:
                            a = a.replace("sekitar sini", '')
                            a += "korok yo "  


                        if "kurang ajar" in self.label.text:
                            a = a.replace("kurang ajar", '')
                            a += "kuang ajea "  

                        if "kucing" in self.label.text:
                            a = a.replace("kucing", '')
                            a += "kucing "  

                        if "kuda" in self.label.text:
                            a = a.replace("kuda", '')
                            a += "kudo "  

                        if "juga" in self.label.text:
                            a = a.replace("juga", '')
                            a += "kulo "  

                        if "baginda" in self.label.text:
                            a = a.replace("baginda", '')
                            a += "kumu "  

                        if "dari" in self.value.text:
                            a = a.replace("dari", '')
                            a += "kunai "  

                        if "derajat" in self.label.text:
                            a = a.replace("derajat", '')
                            a += "kun'eu "  

                        if "tingkat" in self.label.text:
                            a = a.replace("tingkat", '')
                            a += "keun'eu "  

                        if "anjin" in self.label.text:
                            a = a.replace("anjin", '')
                            a += "kuyuk "  

                        if "lahir" in self.label.text:
                            a = a.replace("lahir", '')
                            a += "laher "  

                        if "helai" in self.label.text:
                            a = a.replace("helai", '')
                            a += "lai "  

                        if "sehingga" in self.label.text:
                            a = a.replace("sehingga", '')
                            a += "sehingga "  

                        if "hendak" in self.label.text:
                            a = a.replace("hendak", '')
                            a += "lak "  

                        if "mau"in self.label.text:
                            a += "lak " 
                        if "mau kemana" in self.label.text:
                            a = a.replace("mau kemana", '')
                            a += "lak mai ipe "  

                        if "mau kemana?" in self.label.text:
                            a = a.replace("kemana?", '')
                            a += "lak mai ipe? "  

                        if "lalan" in self.label.text:
                            a = a.replace("lalan", '')
                            a += "lalang "  

                        if "sombong" in self.label.text:
                            a = a.replace("sombong", '')
                            a += "lang uk "  

                        if "angkuh" in self.label.text:
                            a = a.replace("angkuh", '')
                            a += "lang uk "  

                        if "sayur sayuran" in self.label.text:
                            a = a.replace("sayur sayuran", '')
                            a += "lapen "  

                        if "sayur-sayuran" in self.label.text:
                            a = a.replace("sayur-sayuran", '')
                            a += "lapen "  

                        if "gulai" in self.label.text:
                            a = a.replace("gulai", '')
                            a += "lapen "  

                        if "jejak" in self.label.text:
                            a = a.replace("jejak", '')
                            a += "lat "  

                        if "lebih" in self.label.text:
                            a = a.replace("lebih", '')
                            a += "lebeak "  

                        if "lebih baik" in self.label.text:
                            a = a.replace("lebih baik", '')
                            a += "lebeak baik "  

                        if "baris" in self.label.text:
                            a = a.replace("baris", '')
                            a += "le'et "   

                        if "dalam" in self.label.text:
                            a = a.replace("dalam", '')
                            a += "lem "  

                        if "plafon" in self.label.text:
                            a = a.replace("plafon", '')
                            a += "lemen "  

                        if "jeruk" in self.label.text:
                            a = a.replace("jeruk", '')
                            a += "lemeu "  

                        if "lima" in self.label.text:
                            a = a.replace("lima", '')
                            a += "lemo "  

                        if "5" in self.label.text:
                            a = a.replace("5", '')
                            a += "lemo "  

                        if "lepas" in self.label.text:
                            a = a.replace("lepas", '')
                            a += "lepas "  

                        if "bebas" in self.label.text:
                            a = a.replace("bebas", '')
                            a += "lepas "  

                        if "lain" in self.label.text:
                            a = a.replace("lain", '')
                            a += "leyen "  

                        if "lebar" in self.label.text:
                            a = a.replace("lebar", '')
                            a += "libea "  

                        if "licin" in self.label.text:
                            a = a.replace("licin", '')
                            a += "licin "  

                        if "beri" in self.label.text:
                            a = a.replace("beri", '')
                            a += "lie "  

                        if "tersesat" in self.label.text:
                            a = a.replace("tersesat", '')
                            a += "limeu "  

                        if "tersesat jalan" in self.label.text:
                            a = a.replace("tersesat jalan", '')
                            a += "limeu dalen "  

                        if "linggis" in self.label.text:
                            a = a.replace("linggis", '')
                            a += "ling is "  

                        if "suruh" in self.label.text:
                            a = a.replace("suruh", '')
                            a += "lu us "  

                        if "luar" in self.label.text:
                            a = a.replace("luar", '')
                            a += "luea "  

                        if "sekali" in self.label.text:
                            a = a.replace("sekali", '')
                            a += "lut "  

                        if "lurus" in self.label.text:
                            a = a.replace("lurus", '')
                            a += "lu us "  

                        if "mancur" in self.label.text:
                            a = a.replace("mancur", '')
                            a += "macoa "  

                        if "menghadap" in self.label.text:
                            a = a.replace("menghadap", '')
                            a += "madep "  

                        if "kepada" in self.label.text:
                            a = a.replace("kepada", '')
                            a += "megea "  

                        if "mendatangi" in self.label.text:
                            a = a.replace("mendatangi", '')
                            a += "magea "  

                        if "ke" in self.label.text:
                            a = a.replace("ke", '')
                            if not "keracok" in self.label.text:
                                if "ke sini" in self.label.text :
                                    a = a.replace("ke sini", '')
                                    a += "man ai/min'ai "  
            
                                elif "ke atas" in self.label.text:
                                    a = a.replace("ke atas", '')
                                    a += "min as "  
            
                                elif "kesana" in self.label.text:
                                    a = a.replace("kesana", '')
                                    a += "min i "  
            
                                else:
                                    a += "mai " 
                        if "mengajak" in self.label.text:
                            a = a.replace("mengajak", '')
                            a += "majak "  

                        if "mengajar" in self.label.text:
                            a = a.replace("mengajar", '')
                            a += "majea "  

                        if "tetap" in self.label.text:
                            a = a.replace("tetap", '')
                            a += "maju "  

                        if "mengambil" in self.label.text:
                            a = a.replace("mengambil", '')
                            a += "mak "  

                        if "pakai" in self.label.text:
                            a = a.replace("pakai", '')
                            a += "makie "  

                        if "supaya" in self.label.text:
                            a = a.replace("supaya", '')
                            a += "mako "  

                        if "sehingga" in self.label.text:
                            a = a.replace("sehingga", '')
                            a += "mako "  

                        if "maksud" in self.label.text:
                            a = a.replace("maksud", '')
                            a += "maksut "

                        if "menghalau" in self.label.text:
                            a = a.replace("menghalau", '')
                            a += "malau "  

                        if "membuang" in self.label.text:
                            a = a.replace("membuang", '')
                            a += "mam'ung/mam ung "  

                        if "amanat" in self.label.text:
                            a = a.replace("amanat", '')
                            a += "manat "  

                        if "manggis" in self.label.text:
                            a = a.replace("manggis", '')
                            a += "mang us "  

                        if "mendatangi" in self.label.text:
                            a = a.replace("mendatangi", '')
                            a += "man un "  

                        if "berperang" in self.label.text:
                            a = a.replace("berperang", '')
                            a += "man un "  

                        if "mari" in self.label.text:
                            a = a.replace("mari", '')
                            a += "maro "  

                        if "mustahil" in self.label.text:
                            a = a.replace("mustahil", '')
                            a += "maso "  

                        if "mati" in self.label.text:
                            a = a.replace("mati", '')
                            a += "matie "  

                        if "meninggal" in self.label.text:
                            a = a.replace("meninggal", '')
                            a += "matie "  

                        if "meninggal dunia" in self.label.text:
                            a = a.replace("meninggal dunia", '')
                            a += "matie "  

                        if "berburu" in self.label.text:
                            a = a.replace("berburu", '')
                            a += "mebureuet "  

                        if "merebut" in self.label.text:
                            a = a.replace("merebut", '')
                            a += "mebut "  

                        if "bermacam macam" in self.label.text:
                            a = a.replace("bermacam macam", '')
                            a += "mecem "  

                        if "bermacam-macam" in self.label.text:
                            a = a.replace("bermacam-macam", '')
                            a += "mecem "  

                        if "menyirami" in self.label.text:
                            a = a.replace("menyirami", '')
                            a += "mecik "  

                        if "masuk ke dalam rumah" in self.label.text:
                            a = a.replace("dalam rumah", '')
                            a += "medasie "  

                        if "hulu" in self.label.text:
                            a = a.replace("hulu", '')
                            a += "medek "  

                        if "merasa pedih" in self.label.text:
                            a = a.replace("merasa pedih", '')
                            a += "meding "  

                        if "memanggil" in self.label.text:
                            a = a.replace("memanggil", '')
                            a += "meduo "  

                        if "memeluk" in self.label.text:
                            a = a.replace("memeluk", '')
                            a += "megep "  

                        if "memegang" in self.label.text:
                            a = a.replace("memegang", '')
                            a += "megong "  

                        if "memekakan" in self.label.text:
                            a = a.replace("memekakan", '')
                            a += "mekak "  

                        if "berpikir" in self.label.text:
                            a = a.replace("berpikir", '')
                            a += "meker "  

                        if "mengembara" in self.label.text:
                            a = a.replace("mengembara", '')
                            a += "melarat "  

                        if "memberi" in self.label.text:
                            a = a.replace("memberi", '')
                            a += "melie "  

                        if "memberitahu" in self.label.text:
                            a = a.replace("memberitahu", '')
                            a += "melie namen "  

                        if "lari" in self.label.text:
                            a = a.replace("lari", '')
                            a += "mengacap "  

                        if "lewat" in self.label.text:
                            a = a.replace("lewat", '')
                            a += "melitas "  

                        if "suruh" in self.label.text:
                            a = a.replace("suruh", '')
                            a += "meloak "  

                        if "melempar" in self.label.text:
                            a = a.replace("melempar", '')
                            a += "meluk "  

                        if "memanah" in self.label.text:
                            a = a.replace("memanah", '')
                            a += "memana "  

                        if "meman" in self.label.text:
                            a = a.replace("meman", '')
                            a += "memang "  

                        if "buat" in self.label.text:
                            a = a.replace("buat", '')
                            a += "menea "  

                        if "menemani" in self.label.text:
                            a = a.replace("menemani", '')
                            a += "men'es/men es "  

                        if "lari" in self.label.text:
                            a = a.replace("lari", '')
                            a += "mengacap "  

                        if "mengamuk" in self.label.text:
                            a = a.replace("mengamuk", '')
                            a += "mengamuk "  

                        if "marah" in self.label.text:
                            a = a.replace("marah", '')
                            a += "mengeak "  

                        if "menjerit" in self.label.text:
                            a = a.replace("menjerit", '')
                            a += "mengekik "  

                        if "menangis" in self.label.text:
                            a = a.replace("menangis", '')
                            a += "mengin'oi/mengin oi "  

                        if "menembak" in self.label.text:
                            a = a.replace("menembak", '')
                            a += "menim ak/menim'ak "  

                        if "manusia" in self.label.text:
                            a = a.replace("manusia", '')
                            a += "menusyo "  

                        if "bersiap siap" in self.label.text:
                            a = a.replace("bersiap siap", '')
                            a += "menyiep "  

                        if "bersiap-siap" in self.label.text:
                            a = a.replace("bersiap-siap", '')
                            a += "menyiep "  

                        if "menaruh" in self.label.text:
                            a = a.replace("menaruh", '')
                            a += "mepek "  

                        if "meletakkan" in self.label.text:
                            a = a.replace("meletakkan", '')
                            a += "mepek "  

                        if "mencuci" in self.label.text:
                            a = a.replace("mencuci", '')
                            a += "mepuk "  

                        if "memerangi" in self.label.text:
                            a = a.replace("memerangi", '')
                            a += "merang "  

                        if "masak" in self.label.text:
                            a = a.replace("masak", '')
                            a += "mesak "  

                        if "mencari" in self.label.text:
                            a = a.replace("mencari", '')
                            a += "mesoa "  

                        if "jalan jalan" in self.label.text:
                            a = a.replace("jalan jalan", '')
                            a += "meto "  

                        if "jalan-jalan" in self.label.text:
                            a = a.replace("jalan-jalan", '')
                            a += "meto "  

                        if "memelihara" in self.label.text:
                            a = a.replace("memelihara", '')
                            a += "midup "  

                        if "mengikuti" in self.label.text:
                            a = a.replace("mengikuti", '')
                            a += "mileu "  

                        if "ikut" in self.label.text:
                            a = a.replace("ikut", '')
                            a += "mileu "  

                        if "berbicara" in self.label.text:
                            a = a.replace("berbicara", '')
                            a += "miling "  

                        if "hilir" in self.label.text:
                            a = a.replace("hilir", '')
                            a += "milot "  

                        if "menghina" in self.label.text:
                            a = a.replace("menghina", '')
                            a += "mimak "  

                        if "mengintip" in self.label.text:
                            a = a.replace("mengintip", '')
                            a += "mim'ang "  

                        if "membawa" in self.label.text:
                            a = a.replace("membawa", '')
                            a += "m'in "  

                        if "ke sini" in self.label.text:
                            a = a.replace("ke sini", '')
                            a += "man ai/min'ai "  

                        if "ke atas" in self.label.text:
                            a = a.replace("ke atas", '')
                            a += "min as "  

                        if "kesana" in self.label.text:
                            a = a.replace("kesana", '')
                            a += "min i "  

                        if "bocor" in self.label.text:
                            a = a.replace("bocor", '')
                            a += "minoa "  

                        if "misal" in self.label.text:
                            a = a.replace("misal", '')
                            a += "misal "  

                        if "misalnya" in self.label.text:
                            a = a.replace("misalnya", '')
                            a += "misal ne "  

                        if "terus menerus" in self.label.text:
                            a = a.replace("terus menerus", '')
                            a += "mogoa "  

                        if "mujur" in self.label.text:
                            a = a.replace("mujur", '')
                            a += "mojoa "  

                        if "membunuh" in self.label.text:
                            a = a.replace("membunuh", '')
                            a += "monoak "  

                        if "ayam" in self.label.text:
                            a = a.replace("ayam", '')
                            a += "monok "  

                        if "hanyut" in self.label.text:
                            a = a.replace("hanyut", '')
                            a += "monot "

                        if "membuang" in self.label.text:
                            a = a.replace("membuang", '')
                            a += "muang "   

                        if "bukalah" in self.label.text:
                            a = a.replace("bukalah", '')
                            a += "mukak "  

                        if "membungkus" in self.label.text:
                            a = a.replace("membungkus", '')
                            a += "mukus "  

                        if "mulai" in self.label.text:
                            a = a.replace("mulai", '')
                            a += "mulai "  

                        if "di" in self.label.text:

                            if "diajar" in self.label.text:
                                a = a.replace("diajar", '')
                                a += "najea "  
        
                            elif "dingin" in self.label.text:
                                a = a.replace("dingin", '')
                                a += "sêngok  "
        
                            elif "dihalau" in self.label.text:
                                a = a.replace("dihalau", '')
                                a += "nalau "  
        
                            elif "dikawinkan" in self.label.text:
                                a = a.replace("dikawinkan", '')
                                a += "napag "  
        
                            elif "dilontok" in self.label.text:
                                a = a.replace("dilontok", '')
                                a += "nating "  
        
                            elif "direbut" in self.label.text:
                                a = a.replace("direbut", '')
                                a += "nebut "  
        
                            elif "dipercik" in self.label.text:
                                a = a.replace("dipercik", '')
                                a += "necik "  
        
                            elif "dipegang" in self.label.text:
                                a = a.replace("dipegang", '')
                                a += "negong "  
        
                            elif "diikat" in self.label.text:
                                a = a.replace("diikat", '')
                                a += "neket "  
        
                            elif "dimarahi" in self.label.text:
                                a = a.replace("dimarahi", '')
                                a += "nengeak "  
        
                            elif "padi" in self.label.text:
                                print("beda")
                            else:
                                a = a.replace("di", '')
                                a += "nak " 
                        if "bisa" in self.label.text:
                            a = a.replace("bisa", '')
                            a += "nam "  

                        if "tahu" in self.label.text:
                            a = a.replace("tahu", '')
                            a += "namen "  

                        if "mengetahui" in self.label.text:
                            a = a.replace("mengetahui", '')
                            a += "namen "  

                        if "tadi" in self.label.text:
                            a = a.replace("tadi", '')
                            a += "nano "  

                        if "kerajaan" in self.label.text:
                            a = a.replace("kerajaan", '')
                            a += "negrei "  

                        if "mengakui" in self.label.text:
                            a = a.replace("mengakui", '')
                            a += "ngakok "  

                        if "menetes" in self.label.text:
                            a = a.replace("menetes", '')
                            a += "ngecacak "  

                        if "dengan" in self.label.text:
                            a = a.replace("dengan", '')
                            a += "ngen "  

                        if "dengan hormat" in self.label.text:
                            a = a.replace("dengan hormat", '')
                            a += "ngen baik "  

                        if "bercakap cakap" in self.label.text:
                            a = a.replace("bercakap cakap", '')
                            a += "ngota "  

                        if "bercakap-cakap" in self.label.text:
                            a = a.replace("bercakap-cakap", '')
                            a += "ngota "  

                        if "mengobrol" in self.label.text:
                            a = a.replace("mengobrol", '')
                            a += "ngota "  

                        if "dibidik" in self.label.text:
                            a = a.replace("dibidik", '')
                            a += "nidik "  

                        if "sekal" in self.label.text:
                            a = a.replace("sekal", '')
                            a += "nien "  

                        if "nian" in self.label.text:
                            a = a.replace("nian", '')
                            a += "nien "  

                        if "menikah" in self.label.text:
                            a = a.replace("menikah", '')
                            a += "nikeak "  

                        if "kakek" in self.label.text:
                            a = a.replace("kakek", '')
                            a += "ninik "  

                        if "nenek" in self.label.text:
                            a = a.replace("nenek", '')
                            a += "ninik "  

                        if "terus menerus" in self.label.text:
                            a = a.replace("terus menerus", '')
                            a += "nogoa "  

                        if "nomor" in self.label.text:
                            a = a.replace("nomor", '')
                            a += "nomor "  

                        if "dihanyut" in self.label.text:
                            a = a.replace("dihanyut", '')
                            a += "nonot "  

                        if "mu" in self.label.text:
                            if not "mukmei " in self.label.text:
                                a = a.replace("nu ", '')
                                a += "nu "
        
                        if "dibungkus" in self.label.text:
                            a = a.replace("dibungkus", '')
                            a += "nukus "  

                        if "dicampur" in self.label.text:
                            a = a.replace("dicampur", '')
                            a += "nun'ak "

                        if "niat" in self.label.text:
                            a = a.replace("niat", '')
                            a += "nyut "  

                        if "itu"in self.label.text:
                            a += "o " 
                        if "jauh" in self.label.text:
                            a = a.replace("jauh", '')
                            a += "oak "      

                        if "panda" in self.label.text:
                            a = a.replace("panda", '')
                            a += "pacak "      

                        if "terampil" in self.label.text:
                            a = a.replace("terampil", '')
                            a += "pacak "  

                        if "pancuran" in self.label.text:
                            a = a.replace("pancuran", '')
                            a += "pacoa "  

                        if "alangkah" in self.label.text:
                            a = a.replace("alangkah", '')
                            a += "padeak "  

                        if "baik" in self.label.text:
                            a = a.replace("baik", '')
                            a += "padék "

                        if "loten" in self.label.text:
                            a = a.replace("loten", '')
                            a += "pageu "  

                        if "memakai" in self.label.text:
                            a = a.replace("memakai", '')
                            a += "pakei "  

                        if "keahlian" in self.label.text:
                            a = a.replace("keahlian", '')
                            a += "pakié "  

                        if "ilmu" in self.label.text:
                            a = a.replace("ilmu", '')
                            a += "pakié "  

                        if "palin" in self.label.text:
                            a = a.replace("palin", '')
                            a += "paling "  

                        if "panas" in self.label.text:
                            a = a.replace("panas", '')
                            a += "panes "  

                        if "wajah" in self.label.text:
                            a = a.replace("wajah", '')
                            a += "papa "  

                        if "parau" in self.label.text:
                            a = a.replace("parau", '')
                            a += "pa'uo "  

                        if "pecah" in self.label.text:
                            a = a.replace("pecah", '')
                            a += "pecoak "  

                        if "sampah" in self.label.text:
                            a = a.replace("sampah", '')
                            a += "pegas "  

                        if "taruh" in self.label.text:
                            a = a.replace("taruh", '')
                            a += "pék "  

                        if "meletakan" in self.label.text:
                            a = a.replace("meletakan", '')
                            a += "pék "  

                        if "berpikir" in self.label.text:
                            a = a.replace("berpikir", '')
                            a += "pékér "  

                        if "kelakuan" in self.label.text:
                            a = a.replace("kelakuan", '')
                            a += "pekué "  

                        if "pedas" in self.label.text:
                            a = a.replace("pedas", '')
                            a += "pelgéak "  

                        if "tujuan" in self.label.text:
                            a = a.replace("tujuan", '')
                            a += "pemanuo "  

                        if "tujuan" in self.label.text:
                            a = a.replace("tujuan", '')
                            a += "pemanuo "  

                        if "arah" in self.label.text:
                            a = a.replace("arah", '')
                            a += "pemanuo "  

                        if "tempat" in self.label.text:
                            a = a.replace("tempat", '')
                            a += "penan "  

                        if "pemandangan" in self.label.text:
                            a = a.replace("pemandangan", '')
                            a += "pengeléak "  

                        if "hadiah" in self.label.text:
                            a = a.replace("hadiah", '')
                            a += "pengelié "  

                        if "temuan" in self.label.text:
                            a = a.replace("temuan", '')
                            a += "penmeu "  

                        if "bersedih" in self.label.text:
                            a = a.replace("bersedih", '')
                            a += "penyebit "  

                        if "pembersihan" in self.label.text:
                            a = a.replace("pembersihan", '')
                            a += "penyiep "  

                        if "persiapan" in self.label.text:
                            a = a.replace("persiapan", '')
                            a += "penyiep "  

                        if "akhirnya" in self.label.text:
                            a = a.replace("akhirnya", '')
                            a += "penyudo "  

                        if "peran" in self.label.text:
                            a = a.replace("peran", '')
                            a += "perang "  

                        if "pesan" in self.label.text:
                            a = a.replace("pesan", '')
                            a += "pesen "  

                        if "peti" in self.label.text:
                            a = a.replace("peti", '')
                            a += "petei "  

                        if "palu" in self.label.text:
                            a = a.replace("palu", '')
                            a += "petus "  

                        if "jitu" in self.label.text:
                            a = a.replace("jitu", '')
                            a += "pidik "  

                        if "pirin" in self.label.text:
                            a = a.replace("pirin", '')
                            a += "ping'an "  

                        if "pisan" in self.label.text:
                            a = a.replace("pisan", '')
                            a += "pisang "  

                        if "bungsu" in self.label.text:
                            a = a.replace("bungsu", '')
                            a += "piset "  

                        if "pisau" in self.label.text:
                            a = a.replace("pisau", '')
                            a += "pisuo "  

                        if "paran" in self.label.text:
                            a = a.replace("paran", '')
                            a += "pitat "  

                        if "sini" in self.value.text:
                            a = a.replace("sini", '')
                            if not "ke sini" in self .value.text and not "disini" in self.value.text:
                                a = a.replace("sini", '')
                                a += "piyo "  
        
                        if "terus menerus" in self.label.text:
                            a = a.replace("terus menerus", '')
                            a += "pogoa "  

                        if "pokok" in self.label.text:
                            a = a.replace("pokok", '')
                            a += "pokok "  

                        if "puluh" in self.label.text:
                            a = a.replace("puluh", '')
                            a += "poloak "  

                        if "pondok" in self.label.text:
                            a = a.replace("pondok", '')
                            a += "pon'ok "  

                        if "puar" in self.label.text:
                            a = a.replace("puar", '')
                            a += "puea "  

                        if "pohon" in self.label.text:
                            a = a.replace("pohon", '')
                            a += "pun "  

                        if "putus" in self.label.text:
                            a = a.replace("putus", '')
                            a += "putus "  

                        if "hiasi" in self.label.text:
                            a = a.replace("hiasi", '')
                            a += "raes "  

                        if "raja" in self.label.text:
                            a = a.replace("raja", '')
                            a += "rajo "  

                        if "ramai" in self.label.text:
                            a = a.replace("ramai", '')
                            a += "rami "  

                        if "rakyat" in self.label.text:
                            a = a.replace("rakyat", '')
                            a += "ra'yat "  

                        if "pusin" in self.label.text:
                            a = a.replace("pusin", '')
                            a += "renyeng "  

                        if "gembira" in self.label.text:
                            a = a.replace("gembira", '')
                            a += "riang "  

                        if "sadar" in self.label.text:
                            a = a.replace("sadar", '')
                            a += "sadar "  

                        if "suara" in self.label.text:
                            a = a.replace("suara", '')
                            a += "sa'ie "  

                        if "kecewa" in self.label.text:
                            a = a.replace("kecewa", '')
                            a += "sak "  

                        if "sejak" in self.label.text:
                            a = a.replace("sejak", '')
                            a += "sak "  

                        if "sakit" in self.label.text:
                            a = a.replace("sakit", '')
                            a += "sakit "  

                        if "sangka" in self.label.text:
                            a = a.replace("sangka", '')
                            a += "sako "  

                        if "tersangkut" in self.label.text:
                            a = a.replace("tersangkut", '')
                            a += "sakut "  

                        if "kesalahan" in self.label.text:
                            a = a.replace("kesalahan", '')
                            a += "saleak "  

                        if "sama" in self.label.text:
                            a = a.replace("sama", '')
                            a += "samo "  

                        if "sapi" in self.label.text:
                            a = a.replace("sapi", '')
                            a += "sapei "  

                        if "sampa" in self.label.text:
                            a = a.replace("sampa", '')
                            a += "sapie "  

                        if "syarat" in self.label.text:
                            a = a.replace("syarat", '')
                            a += "sarat "  

                        if "tangguk" in self.label.text:
                            a = a.replace("tangguk", '')
                            a += "sauk "  

                        if "sayan" in self.label.text:
                            a = a.replace("sayan", '')
                            a += "sayang "  

                        if "berangkat" in self.label.text:
                            a = a.replace("berangkat", '')
                            a += "seak "  

                        if "sebab" in self.label.text:
                            a = a.replace("sebab", '')
                            a += "sebap "

                        if "bersedih" in self.label.text:
                            a = a.replace("bersedih", '')
                            a += "sebit "  

                        if "sedih" in self.label.text:
                            a = a.replace("sedih", '')
                            a += "sebit "  

                        if "secara" in self.label.text:
                            a = a.replace("secara", '')
                            a += "secao "  

                        if "perempuan" in self.label.text:
                            a = a.replace("perempuan", '')
                            a += "selawie "  

                        if "malu" in self.label.text:
                            a = a.replace("malu", '')
                            a += "seleg "  

                        if "tersinggung" in self.label.text:
                            a = a.replace("tersinggung", '')
                            a += "seleg "  

                        if "laki laki" in self.label.text:
                            a = a.replace("laki laki", '')
                            a += "semanie "  

                        if "laki-laki" in self.label.text:
                            a = a.replace("laki-laki", '')
                            a += "semaine "  

                        if "siluman" in self.label.text:
                            a = a.replace("siluman", '')
                            a += "semat "  

                        if "setan" in self.label.text:
                            a = a.replace("setan", '')
                            a += "semat "  

                        if "menyelidiki" in self.label.text:
                            a = a.replace("menyelidiki", '')
                            a += "semelidik "  

                        if "selidik" in self.label.text:
                            a = a.replace("selidik", '')
                            a += "semelidik "  

                        if "sergap" in self.label.text:
                            a = a.replace("sergap", '')
                            a += "semergap "  

                        if "mengiris" in self.label.text:
                            a = a.replace("mengiris", '')
                            a += "semisit "  

                        if "menyakiti" in self.label.text:
                            a = a.replace("menyakiti", '')
                            a += "semisit "  

                        if "menyingsing" in self.label.text:
                            a = a.replace("menyingsing", '')
                            a += "semsing "  

                        if "mengikuti jejak" in self.label.text:
                            a = a.replace("mengikuti jejak", '')
                            a += "semsung lat "  

                        if "gadis" in self.label.text:
                            a = a.replace("gadis", '')
                            a += "semulen "  

                        if "menyapu" in self.label.text:
                            a = a.replace("menyapu", '')
                            a += "semupeu "  

                        if "diceraikan" in self.label.text:
                            a = a.replace("diceraikan", '')
                            a += "sena'ak "  

                        if "disambut" in self.label.text:
                            a = a.replace("disambut", '')
                            a += "senam ut "  

                        if "ditemukan" in self.label.text:
                            a = a.replace("ditemukan", '')
                            a += "senam ut "  

                        if "gembira" in self.label.text:
                            a = a.replace("gembira", '')
                            a += "senang "  

                        if "senan" in self.label.text:
                            a = a.replace("senan", '')
                            a += "senang "  

                        if "selera" in self.label.text:
                            a = a.replace("selera", '')
                            a += "seneak "  

                        if "sungsuh" in self.label.text:
                            a = a.replace("sungsuh", '')
                            a += "seng eak "  

                        if "diperhatikan" in self.label.text:
                            a = a.replace("diperhatikan", '')
                            a += "senido "  

                        if "dilukai" in self.label.text:
                            a = a.replace("dilukai", '')
                            a += "senilak "  

                        if "diiris" in self.label.text:
                            a = a.replace("diiris", '')
                            a += "senisit "  

                        if "dicium" in self.label.text:
                            a = a.replace("dicium", '')
                            a += "deium "  

                        if "sergayu" in self.label.text:
                            a = a.replace("sergayu", '')
                            a += "sergayeu "  

                        if "celana" in self.label.text:
                            a = a.replace("celana", '')
                            a += "serwa "  

                        if "dia"in self.label.text:
                            a += "si " 
                        if "mereka" in self.label. text:
                            a = a.replace("mereka", '')
                            a += "si "  

                        if "siamang" in self.label.text:
                            a = a.replace("siamang", '')
                            a += "siamang "  

                        if "bersiap" in self.label.text:
                            a = a.replace("bersiap", '')
                            a += "siap "  

                        if "sifat" in self.label.text:
                            a = a.replace("sifat", '')
                            a += "sifet "  

                        if "cuka" in self.label.text:
                            a = a.replace("cuka", '')
                            a += "sileak "  

                        if "persimpangan" in self.label.text:
                            a = a.replace("persimpangan", '')
                            a += "sipang "  

                        if "iri"in self.label.text:
                            a += "siut " 
                        if "sendirian" in self.label.text:
                            a = a.replace("sendirian", '')
                            a += "suang "  

                        if "suara" in self.label.text:
                            a = a.replace("suara", '')
                            a += "sua'o "  

                        if "sudah" in self.label.text:
                            a = a.replace("sudah", '')
                            a += "sudo "  

                        if "kaya" in self.label.text:
                            a = a.replace("kaya", '')
                            a += "sugeak "  

                        if "mari" in self.label.text:
                            a = a.replace("mari", '')
                            a += "tai "  

                        if "talan" in self.label.text:
                            a = a.replace("talan", '')
                            a += "talang "  

                        if "bertambah" in self.label.text:
                            a = a.replace("bertambah", '')
                            a += "tam'eak "  

                        if "tangan" in self.label.text:
                            a = a.replace("tangan", '')
                            a += "tangen "  

                        if "bertanding" in self.label.text:
                            a = a.replace("bertanding", '')
                            a += "tan ing "  

                        if "tanda" in self.label.text:
                            a = a.replace("tanda", '')
                            a += "tan'o "  

                        if "baru akan" in self.label.text:
                            a = a.replace("baru akan", '')
                            a += "tapie "  

                        if "sebelum" in self.label.text:
                            a = a.replace("sebelum", '')
                            a += "tapie "  

                        if "tawa" in self.label.text:
                            a = a.replace("tawa", '')
                            a += "tawei "  

                        if "kita" in self.label.text:
                            a = a.replace("kita", '')
                            a += "te "  

                        if "ayah" in self.label.text:
                            a = a.replace("ayah", '')
                            a += "teak "  

                        if "entah" in self.label.text:
                            a = a.replace("entah", '')
                            a += "teak ba "  

                        if "entah?" in self.label.text:
                            a = a.replace("entah?", '')
                            a += "teak ba? "  

                        if "terhenti" in self.label.text:
                            a = a.replace("terhenti", '')
                            a += "tebedan "  

                        if "bendungan" in self.label.text:
                            a = a.replace("bendungan", '')
                            a += "tebet "  

                        if "gunung" in self.label.text:
                            a = a.replace("gunun", '')
                            a += "tebo "  

                        if "bukit" in self.label.text:
                            a = a.replace("bukit", '')
                            a += "tebo "  

                        if "bukit tepuk" in self.label.text:
                            a = a.replace("bukit tepuk", '')
                            a += "tebo tepuk "  

                        if "berdiri tegak" in self.label.text:
                            a = a.replace("berdiri tegak", '')
                            a += "teje "  

                        if "termakan" in self.label.text:
                            a = a.replace("termakan", '')
                            a += "tekem'uk "  

                        if "terkejut" in self.label.text:
                            a = a.replace("terkejut", '')
                            a += "tekjir "  

                        if "terlihat" in self.label.text:
                            a = a.replace("terlihat", '')
                            a += "tekleak "  

                        if "datan" in self.label.text:
                            a = a.replace("datan", '')
                            a += "teko "  

                        if "kembali untuk dua kali" in self.label.text:
                            a = a.replace("dua kali", '')
                            a += "teko kaben yo keduei "  

                        if "terkenal" in self.label.text:
                            a = a.replace("terkenal", '')
                            a += "tekujat "  

                        if "tiga" in self.label.text:
                            a = a.replace("tiga", '')
                            a += "teleu "  

                        if "menegur" in self.label.text:
                            a = a.replace("menegur", '')
                            a += "tema'ak "  

                        if "menangkap" in self.label.text:
                            a = a.replace("menangkap", '')
                            a += "temakep "  

                        if "mandul" in self.label.text:
                            a = a.replace("mandul", '')
                            a += "temanang "  

                        if "bertanya" in self.label.text:
                            a = a.replace("bertanya", '')
                            a += "tamanye "  

                        if "menertawakan" in self.label.text:
                            a = a.replace("menertawakan", '')
                            a += "temawei "  

                        if "menghina" in self.label.text:
                            a = a.replace("menghina", '')
                            a += "tem eak "  

                        if "merendahkan" in self.label.text:
                            a = a.replace("merendahkan", '')
                            a += "tem eak "  

                        if "menunggang kuda" in self.label.text:
                            a = a.replace("menunggang kuda", '')
                            a += "temeng'ek kudo "  

                        if "temu" in self.label.text:
                            a = a.replace("temu", '')
                            a += "temeu "  

                        if "menamakan" in self.label.text:
                            a = a.replace("menamakan", '')
                            a += "temgen "  

                        if "tinggalkan" in self.label.text:
                            a = a.replace("tinggalkan", '')
                            a += "teming'a "  

                        if "mendengarkan" in self.label.text:
                            a = a.replace("mendengarkan", '')
                            a += "teming uk "  

                        if "peluru" in self.label.text:
                            a = a.replace("peluru", '')
                            a += "temleu "  

                        if "bertemu" in self.label.text:
                            a = a.replace("bertemu", '')
                            a += "temmeu "  

                        if "mendengar" in self.label.text:
                            a = a.replace("mendengar", '')
                            a += "temngoa "  

                        if "duduk" in self.label.text:
                            a = a.replace("duduk", '')
                            a += "temot "  

                        if "menuruti" in self.label.text:
                            a = a.replace("menuruti", '')
                            a += "temetoa "  

                        if "sesuai" in self.label.text:
                            a = a.replace("sesuai", '')
                            a += "temetoa "  

                        if "memotong" in self.label.text:
                            a = a.replace("memotong", '')
                            a += "temtok "  

                        if "mempunyai" in self.label.text:
                            a = a.replace("mempunyai", '')
                            a += "temuan "  

                        if "menolong" in self.label.text:
                            a = a.replace("menolong", '')
                            a += "temulung "  

                        if "menunjukan" in self.label.text:
                            a = a.replace("menunjukan", '')
                            a += "temun'juk "  

                        if "menurunkan" in self.label.text:
                            a = a.replace("menurunkan", '')
                            a += "menurunkan "  

                        if "ditertawakan" in self.label.text:
                            a = a.replace("ditertawakan", '')
                            a += "tenawei "  

                        if "kapan" in self.label.text:
                            a = a.replace("kapan", '')
                            a += "tengen "  

                        if "kapan?" in self.label.text:
                            a = a.replace("kapan?", '')
                            a += "tengen? "  

                        if "dinamakan" in self.label.text:
                            a = a.replace("dinamakan", '')
                            a += "tengen "  

                        if "dengar" in self.label.text:
                            a = a.replace("dengar", '')
                            a += "tengoa "  

                        if "didengar" in self.label.text:
                            a = a.replace("didengar", '')
                            a += "tenngoa "  

                        if "tentara" in self.label.text:
                            a = a.replace("tentara", '')
                            a += "tentera "  

                        if "bahan pakaian yang dicuci" in self.label.text:
                            a = a.replace("yang dicuci", '')
                            a += "tepap "

                        if "terikat" in self.label.text:
                            a = a.replace("terikat", '')
                            a += "tepeket "   

                        if "terus" in self.label.text:
                            a = a.replace("terus", '')
                            a += "terus "  

                        if "tidur" in self.label.text:
                            a = a.replace("tidur", '')
                            a += "tidoa "  

                        if "tali" in self.label.text:
                            a = a.replace("tali", '')
                            a += "tilei "  

                        if "timbak" in self.label.text:
                            a = a.replace("timbak", '')
                            a += "tim'ak "  

                        if "tinggal" in self.label.text:
                            a = a.replace("tinggal", '')
                            a += "ting'a "  

                        if "teringat" in self.label.text:
                            a = a.replace("teringat", '')
                            a += "tinget "  

                        if "setiap" in self.label.text:
                            a = a.replace("setiap", '')
                            a += "tip "  

                        if "kecil" in self.label.text:
                            a = a.replace("kecil", '')
                            a += "titik "  

                        if "telinga" in self.label.text:
                            a = a.replace("telinga", '')
                            a += "ti'uk "  

                        if "mereka semua" in self.label.text:
                            a = a.replace("mereka semua", '')
                            a += "tobo'o "  

                        if "mereka ini" in self.label.text:
                            a = a.replace("mereka ini", '')
                            a += "tobo yo "  

                        if "beli" in self.label.text:
                            a = a.replace("beli", '')
                            a += "tokoa "  

                        if "turut" in self.label.text:
                            a = a.replace("turut", '')
                            a += "totoa "  

                        if "tuhan" in self.label.text:
                            a = a.replace("tuhan", '')
                            a += "tuhan "  

                        if "koki" in self.label.text:
                            a = a.replace("koki", '')
                            a += "tukang kesak "  

                        if "juru cuci" in self.label.text:
                            a = a.replace("juru cuci", '')
                            a += "tukang mepuk ping“an "  

                        if "babu cuci" in self.label.text:
                            a = a.replace("babu cuci", '')
                            a += "tukang tepap "  

                        if "tolong" in self.label.text:
                            a = a.replace("tolong", '')
                            a += "tulung "  

                        if "tolong menolong" in self.label.text:
                            a = a.replace("tolong menolong", '')
                            a += "tulung-menulung "  

                        if "tolong-menolong" in self.label.text:
                            a = a.replace("tolong-menolong", '')
                            a += "tulung-menulung "  

                        if "orang" in self.label.text:
                            a = a.replace("orang", '')
                            a += "tun "  

                        if "pencari rotan" in self.label.text:
                            a = a.replace("pencari rotan", '')
                            a += "tun mesoa ebes "  

                        if "orang beneran" in self.label.text:
                            a = a.replace("orang beneran", '')
                            a += "tun nien "  

                        if "bayi" in self.label.text:
                            a = a.replace("bayi", '')
                            a += "tun titik "  

                        if "turun" in self.label.text:
                            a = a.replace("turun", '')
                            a += "tu'un "  

                        if "kalian" in self.label.text:
                            a = a.replace("kalian", '')
                            a += "udi "  

                        if "sudah" in self.label.text:
                            a = a.replace("sudah", '')
                            a += "udo "  

                        if "ujang" in self.label.text:
                            a = a.replace("ujang", '')
                            a += "Ujang "  

                        if "ujian" in self.label.text:
                            a = a.replace("ujian", '')
                            a += "ujien "  

                        if "ujung" in self.label.text:
                            a = a.replace("ujung", '')
                            a += "ujung "   

                        if "pekerjaan" in self.label.text:
                            a = a.replace("pekerjaan", '')
                            a += "uleak "  

                        if "rupanya" in self.label.text:
                            a = a.replace("rupanya", '')
                            a += "ules o "  

                        if "rumah" in self.label.text:
                            a = a.replace("rumah", '')
                            a += "umeak "  

                        if "ladan" in self.label.text:
                            a = a.replace("ladan", '')
                            a += "umei "  

                        if "pesta perkawinan" in self.label.text:
                            a = a.replace("pesta perkawinan", '')
                            a += "um“ung "  

                        if "upik" in self.label.text:
                            a = a.replace("upik", '')
                            a += "Upik "  

                        if "rusa" in self.label.text:
                            a = a.replace("rusa", '')
                            a += "uso "  

                        if "sekarang" in self.label.text:
                            a = a.replace("sekarang", '')
                            a += "uyo "  

                        if "sebagaimana" in self.label.text:
                            a = a.replace("sebagaimana", '')
                            a += "wai "  
    
                        if "tante" in self.label.text:
                            a = a.replace("tante", '')
                            a += "wak "  

                        if "waktu" in self.label.text:
                            a = a.replace("waktu", '')
                            a += "wakteu "

                        if "perut" in self.label.text:
                            a = a.replace("perut", '')
                            a += "tnie "

                        if "harimau" in self.label.text:
                            a = a.replace("harimau", '')
                            a += "imeu "

                        if "ular" in self.label.text:
                            a = a.replace("ular", '')
                            a += "dung "

                        if "jeruk" in self.label.text:
                            a = a.replace("jeruk", '')
                            a += "beko "

                        if "nangka" in self.label.text:
                            a = a.replace("nangka", '')
                            a += "beko "
                else:
                    self.rejang = True
                    self.babel.text = 'bahasa: rejang ke indonesia'
                    a = self.value.text
                    if "mukmei" in self.label.text or "mbu" in self.label.text:
                        a = a.replace("mukmei", '')
                        a = a.replace("mbu", '')
                        a += "makan "  
                    if "keracok" in self.label.text:
                        a = a.replace("keracok", '')
                        a += "baju "
                    if "cayo" in self.label.text:
                        a = a.replace("cayo", '')
                        a += "cahaya "
                    if "tê'an" in self.label.text:
                        a = a.replace("tê'an", '')
                        a += "terang "
                    if "sinjo" in self.label.text:
                        a = a.replace("sinjo", '')
                        a += "senja "
                    if "bilik" in self.label.text:
                        a = a.replace("bilik", '')
                        a += "kamar "
                    if "berando" in self.label.text:
                        a = a.replace("berando", '')
                        a += "berenda "
                    if "danet" in self.label.text:
                        a = a.replace("danet", '')
                        a += "halaman "
                    if "danea" in self.label.text:
                        a = a.replace("danea", '')
                        a += "teras "
                    if "caci" in self.label.text:
                        a = a.replace("caci", '')
                        a += "uang "
                    if "dio"in self.label.text:
                        a += "ini "
                    if "do'o" in self.label.text:
                        a = a.replace("do'o", '')
                        a += "itu "
                    if "ko" in self.label.text:
                        a = a.replace("ko", '')
                        a += "kamu "
                    if "kumu" in self.label.text:
                        a = a.replace("kumu", '')
                        a += "anda "
                    if "uku"in self.label.text:
                        f = ["saya ", "aku "]
                        a = a.replace("uku", '')
                        a += random.choice(f)
                    if "lok"in self.label.text :
                        a = a.replace("lok", '')
                        a += "mau "
                    if " mei" in self.label.text :
                        a = a.replace(" mei",'')
                        if not "mukmei" in self.label.text:
                            a = a.replace("makan","")
                        
                        a += "nasi "
                    if "poi"in self.label.text :
                        a = a.replace("poi", "")
                        a += "padi "
                    if "kibut" in self.label.text:
                        a = a.replace("kibut", '')
                        a += "bunga bangkai "
                    if "skede" in self.label.text:
                        a = a.replace("skede", '')
                        a += "bunga rafflesia "
                    if "nikeak" in self.label.text:
                        a = a.replace("nikeak", '')
                        a += "nikah "
                    if "api"in self.label.text:
                        a = a.replace("api", "")
                        a += "siapa "
                    if "gen"in self.label.text :
                        a = a.replace("gen", "")
                        a += "nama "
                    if "jibeak" in self.label. text:
                        a = a.replace("jibeak", '')
                        a += "jangan "
                    if "tumbua" in self.label.text:
                        a = a.replace("tumbua", '')
                        a += "tabrak "
                    if "da'et" in self.label.text:
                        a = a.replace("da'et", '')
                        a += "darat "
                    if "datea" in self.label.text:
                        a = a.replace("datea", '')
                        a += "datar "
                    if "tebo" in self.label.text:
                        a = a.replace("tebo", '')
                        a += "gunung/bukit "
                    if "abeak" in self.label.text:
                        a = a.replace("abeak", '')
                        a += "kira kira "
                    if "abis" in self.label.text:
                        a = a.replace("abis", '')
                        a += "habis "
                    if "adat" in self.label.text:
                        a = a.replace("adat", '')
                        a += "kebiasaan "
                    if "ade"in self.label.text:
                        if "sadei" in self.label.text:
                            a = a.replace("sadei", "")
                            a += "desa "
                        else:
                            a = a.replace("ade", '')
                            a += "ada "

                    if "agak" in self.label.text:
                        a = a.replace("agak", '')
                        a += "agak "
                    if "ale" in self.label.text:
                        a = a.replace("ale", '')
                        self.label.text = ' '
                        if "alep" in self.label.text:
                            a = a.replace("alep", '')
                            a += "cantik "

                        if "aleu" in self.label.text:
                            a = a.replace("aleu", '')
                            a += "pergi  "

                            b = self.label.text
                            if 'mai' in self.label.text:
                                b = b.replace('mai', '')
                                a += 'ke  '
        
                                if "cuup" in self.label.text:
                                    a = a.replace("cuup", '')
                                    b = self.label.text
            
                                    b = b.replace('ke', 'curup')
                                    a += b
                                else:
                                    a += b
                            else:
                                pass
                        else:
                            a += "maaf mungkin maksud anda 'aleu?'"
                        if "aleu mai beak im o" in self.label.text:
                            a = a.replace("im o", '')
                            a += "masuk ke hutan "

                        if "aleu mai meto" in self.label.text:
                            a = a.replace("mai meto", '')
                            a += "pergi jalan-jalan "

                    if "amen" in self.label.text:
                        a = a.replace("amen", '')
                        a += "jika "
                    if "ami"in self.label.text:
                        a += "jangan/mungkin "
                    if "anok" in self.label.text:
                        a = a.replace("anok", '')
                        a += "anak "
                    if "anak bueak" in self.label.text:
                        a = a.replace("anak bueak", '')
                        a += "anak buah "
                    if "anak pana" in self.label.text:
                        a = a.replace("anak pana", '')
                        a += "anak panah "
                    if "anak sayang" in self.label.text:
                        a = a.replace("anak sayang", '')
                        a += "anak sayang "
                    if "ang'ar" in self.label.text:
                        a = a.replace("ang'ar", '')
                        a += "anggar "
                    if "angen" in self.label.text:
                        a = a.replace("angen", '')
                        if not "coa si angen" :

                            a += "angan angan "
                    if "angin" in self.label.text:
                        a = a.replace("angin", '')
                        a += "angin "
                    if "apang" in self.label.text:
                        a = a.replace("apang", '')
                        a += "haram "
                    if "apei" in self.label.text:
                        a = a.replace("apei", '')
                        a += "hampa "
                    if "api bai" in self.label.text:
                        a = a.replace("api bai", '')
                        a += "siapa saja "
                    if "areak" in self.label.text:
                        a = a.replace("areak", '')
                        a += "berbagai "
                    if "areak keracok" in self.label.text:
                        a = a.replace("areak keracok", '')
                        a += "berbagai pakaian "
                    if "arung" in self.label.text:
                        a = a.replace("arung", '')
                        a += "agak "
                    if "arus" in self.label.text:
                        a = a.replace("arus", '')
                        a += "harus "
                    if "arus" in self.label.text:
                        a = a.replace("arus", '')
                        a += "seharusnya "
                    if "asal" in self.label.text:
                        a = a.replace("asal", '')
                        a += "asal "
                    if "asal usul" in self.label.text:
                        a = a.replace("asal usul", '')
                        a += "asal usul "
                    if "asei" in self.label.text:
                        a = a.replace("asei", '')
                        a += "rasa "
                    if "asei  in ku" in self.label.text:
                        a = a.replace("in ku", '')
                        a += "kupikir "
                    if "asei asei" in self.label.text:
                        a = a.replace("asei asei", '')
                        a += "akan "
                    if "asoa" in self.label.text:
                        a = a.replace("asoa", '')
                        if "asoak"  in self.label.text:

                            a += "adik"
                            a = a.replace("kadik", 'adik')
                        else:
                            a += "maaf mungkin maksud anda 'asoak'?"
                    if "atau" in self.label.text:
                        a = a.replace("atau", '')
                        a += "atau "
                    if "atep" in self.label.text:
                        a = a.replace("atep", '')
                        a += "atap "
                    if "ati"in self.label.text:
                        a += "belum "
                    if "ati si eng ut" in self .value.text:
                        a = a.replace("eng ut", '')
                        a += "belum waktunya "
                    if "atie" in self.label.text:
                        a = a.replace("atie", '')
                        a += "hati "
                    if "aturan" in self.label.text:
                        a = a.replace("aturan", '')
                        a += "giliran "
                    if "awak" in self.label.text:
                        a = a.replace("awak", '')
                        a += "badan "
                    if "awie" in self.label.text:
                        a = a.replace("awie", '')
                        a += "seperti "
                    if "awieo" in self.label.text:
                        a = a.replace("awieo", '')
                        a += "sepertinya "
                    if "awit" in self.label.text:
                        a = a.replace("awit", '')
                        a += "sering/sebelum "
                    if "ayak" in self.label.text:
                        a = a.replace("ayak", '')
                        a += "adalah "
                    if "babu" in self.label.text:
                        a = a.replace("babu", '')
                        a += "pembantu "
                    if "ba'es" in self.label.text:
                        a = a.replace("ba'es", '')
                        a += "bagus "
                    if "ba'es-ba'es ne" in self.label.text:
                        a = a.replace("ba'es-ba'es ne", '')
                        a += "indah "
                    if "bagei" in self.label.text:
                        a = a.replace("bagei", '')
                        a += "nasib "
                    if "bahayo" in self.label.text:
                        a = a.replace("bahayo", '')
                        a += "bahaya "
                    if "baei" in self.label.text:
                        a = a.replace("baei", '')
                        a += "saja "
                    if "bak"in self.label.text:
                        a += "ayah "
                    if "balak" in self.label.text:
                        a = a.replace("balak", '')
                        a += "musibah "
                    if "bales" in self.label.text:
                        a = a.replace("bales", '')
                        a += "balas "
                    if "banak" in self.label.text:
                        a = a.replace("banak", '')
                        a += "beranak "
                    if "bangso" in self.label.text:
                        a = a.replace("bangso", '')
                        a += "bangsa "
                    if "bapak" in self.label.text:
                        a = a.replace("bapak", '')
                        a += "bapak "
                    if "basoak" in self.label.text:
                        a = a.replace("basoak", '')
                        a += "bersaudara "
                    if "be" in self.label.text:
                        a = a.replace("be", '')
                        a += "nanti "
                    if "beak" in self.label.text:
                        a = a.replace("beak", '')
                        a += "bawah "
                    if "bebak" in self.label.text:
                        a = a.replace("bebak", '')
                        a += "berayah "
                    if "bercabang" in self.label.text:
                        a = a.replace("bercabang", '')
                        a += "becabang "
                    if "beceneu" in self.label.text:
                        a = a.replace("beceneu", '')
                        a += "kicau "
                    if "beci'" in self.label.text:
                        a = a.replace("beci'", '')
                        a += "becerai "
                    if "berduei" in self.label.text:
                        a = a.replace("berduei", '')
                        a += "bedua "
                    if "be et" in self.label.text:
                        a = a.replace("be et", '')
                        a += "berat "
                    if "bein ok" in self.label.text:
                        a = a.replace("bein ok", '')
                        a += "memanggil ibu kepada "
                    if "bejako" in self.label.text:
                        a = a.replace("bejako", '')
                        a += "luar biasa "
                    if "bejijei" in self.label.text:
                        a = a.replace("bejijei", '')
                        a += "menjadi "
                    if "bekakok" in self.label.text:
                        a = a.replace("bekakok", '')
                        a += "berkerja "
                    if "bekbo" in self.label.text:
                        a = a.replace("bekbo", '')
                        a += "berbuah "
                    if "bekenek" in self.label.text:
                        a = a.replace("bekenek", '')
                        a += "memanjat "
                    if "bekesoa" in self.label.text:
                        a = a.replace("bekesoa", '')
                        a += "mencari "
                    if "belakang" in self.label.text:
                        a = a.replace("belakang", '')
                        a += "belakang "
                    if "beras" in self.label.text:
                        a = a.replace("beras", '')
                        a += "beras "
                    if "bele'et" in self.label.text:
                        a = a.replace("bele'et", '')
                        a += "berbaris "
                    if "belek" in self.label.text:
                        a = a.replace("belek", '')
                        a += "pulang "
                    if "belek idup" in self.label.text:
                        a = a.replace("belek idup", '')
                        a += "hidup kembali "
                    if "beleo" in self.label.text:
                        a = a.replace("beleo", '')
                        a += "dulu "
                    if "belpas" in self.label.text:
                        a = a.replace("belpas", '')
                        a += "melahirkan "
                    if "belpas" in self.label.text:
                        a = a.replace("belpas", '')
                        a += "dibiarkan bebas "
                    if "benan" in self.label.text:
                        a = a.replace("benan", '')
                        a += "benang "
                    if "binatang" in self.label.text:
                        a = a.replace("binatang", '')
                        a += "benatang "
                    if "bene" in self.label.text:
                        a = a.replace("bene", '')
                        a += "megapa "
                    if "beninik" in self.label.text:
                        a = a.replace("beninik", '')
                        a += "memanggil nenek kepad a"
                    if "bepanuo" in self.label.text:
                        a = a.replace("bepanuo", '')
                        a += "berjalan "
                    if "berpeker" in self.label.text:
                        a = a.replace("berpeker", '')
                        a += "bepikir "
                    if "berpak" in self.label.text:
                        a = a.replace("berpak", '')
                        a += "bersama "
                    if "besilek" in self.label.text:
                        a = a.replace("besilek", '')
                        a += "silat "
                    if "betakup" in self.label.text:
                        a = a.replace("betakup", '')
                        a += "bertaut "
                    if "betaning" in self.label.text:
                        a = a.replace("betaning", '')
                        a += "bertanding "
                    if "sengok" in self.label.text:
                            a = a.replace("sengok", '')
                            a += "dingin "

                    if "bi" in self.label.text:
                        a = a.replace("bi", '')
                        a += "sudah "
                    if "bi le" in self.label.text:
                        a = a.replace("bi le", '')
                        a += "dewasa "
                    if "biaso" in self.label.text:
                        a = a.replace("biaso", '')
                        a += "biasa "
                    if "bie"in self.label.text:
                        a += "perempuan "
                    if "bilei" in self.label.text:
                        a = a.replace("bilei", '')
                        a += "hari "
                    if "binei" in self.label.text:
                        a = a.replace("binei", '')
                        a += "beranian "
                    if "bioa" in self.label.text:
                        a = a.replace("bioa", '')
                        a += "air sungai/air "
                    if "bisei" in self.label.text:
                        a = a.replace("bisei", '')
                        a += "berisi "
                    if "boak" in self.label.text:
                        a = a.replace("boak", '')
                        a += "buah "
                    if "boloak" in self.label.text:
                        a = a.replace("boloak", '')
                        a += "buah "
                    if "buas" in self.label.text:
                        a = a.replace("buas", '')
                        a += "buas "
                    if "bukie" in self.label.text:
                        a = a.replace("bukie", '')
                        a += "bagus "
                    if "buleak" in self.label.text:
                        a = a.replace("buleak", '')
                        a += "boleh "
                    if "bunge" in self.label.text:
                        a = a.replace("bunge", '')
                        a += "bunga "
                    if "buteu" in self.label.text:
                        a = a.replace("buteu", '')
                        a += "patung/batu "
                    if "buye" in self.label.text:
                        a = a.replace("buye", '')
                        a += "batal "
                    if "buyun" in self.label.text:
                        a = a.replace("buyun", '')
                        a += "buyung "
                    if "ca'o" in self.label.text:
                        a = a.replace("ca'o", '')
                        a += "cara "
                    if "celako" in self.label.text:
                        a = a.replace("celako", '')
                        a += "celaka "
                    if "cem cem" in self.label.text:
                        a = a.replace("cem cem", '')
                        a += "bermacam-macam "
                    if "cermim'ie" in self.label.text:
                        a = a.replace("cermim'ie", '')
                        a += "menyirami "
                    if "cemubo" in self.label.text:
                        a = a.replace("cemubo", '')
                        a += "mencoba "
                    if "cengang" in self.label.text:
                        a = a.replace("cengang", '')
                        a += "tercengang "
                    if "cenubo" in self.label.text:
                        a = a.replace("cenubo", '')
                        a += "dicoba "
                    if "cenu'" in self.label.text:
                        a = a.replace("cenu'", '')
                        a += "disiram "
                    if "cerito" in self.label.text:
                        a = a.replace("cerito", '')
                        a += "alkisah "
                    if "cigei" in self.label.text:
                        a = a.replace("cigei", '')
                        a += "tidak lagi "
                    if "coa"in self.label.text:
                        if self.value.text == "coa an udo o":
                            self.label.text =  "tidak lama berselang "
                        elif self.value.text == "coa ade":
                            self.label.text = "tidak ada "
                        elif self.value.text == "coa si angen":
                            self.label.text = "bukan main "
                        else:
                            a += "tidak "
                    if "cubo" in self.label.text:
                        a = a.replace("cubo", '')
                        a += "coba "
                    if "cuik" in self.label.text:
                        a = a.replace("cuik", '')
                        a += "manja "
                    if "cuko" in self.label.text:
                        a = a.replace("cuko", '')
                        a += "cuka "
                    if "cukup" in self.label.text:
                        a = a.replace("cukup", '')
                        a += "cukup "
                    if "hanya" in self.label.text:
                        a = a.replace("hanya", '')
                        a += "cuma "
                    if "cuman" in self.label.text:
                        a = a.replace("cuman", '')
                        a += "cuma "
                    if "cupek" in self.label.text:
                        a = a.replace("cupek", '')
                        a += "berdampingan "
                    if "cupik" in self.label.text:
                        a = a.replace("cupik", '')
                        a += "bayi "
                    if "dagin" in self.label.text:
                        a = a.replace("dagin", '')
                        a += "daging "
                    if "daleak" in self.label.text:
                        a = a.replace("daleak", '')
                        a += "darah "
                    if "dalen" in self.label.text:
                        a = a.replace("dalen", '')
                        a += "jalan "
                    if "dang" in self.label.text:
                        a = a.replace("dang", '')
                        a += "jangan "
                    if "dapet" in self.label.text:
                        a = a.replace("dapet", '')
                        a += "dapat "
                    if "das"in self.label.text:
                        a += "atas "
                    if "dasie" in self.label.text:
                        a = a.replace("dasie", '')
                        a += "dalam rumah "
                    if "dawen" in self.label.text:
                        a = a.replace("dawen", '')
                        a += "daun "
                    if "do bilei" in self.label.text:
                        a = a.replace("do bilei", '')
                        a += "satu hari "
                    if "decan" in self.label.text:
                        a = a.replace("decan", '')
                        a += "sesaat "
                    if "dee"in self.label.text:
                        a += "disitu "
                    if "dekma" in self.label.text:
                        a = a.replace("dekma", '')
                        a += "mirip "
                    if "delas" in self.label.text:
                        a = a.replace("delas", '')
                        a += "cepat "
                    if "demulei" in self.label.text:
                        a = a.replace("demulei", '')
                        a += "pedulikan "
                    if "denam" in self.label.text:
                        a = a.replace("denam", '')
                        a += "didepan "
                    if "dete" in self.label.text:
                        a = a.replace("dete", '')
                        a += "duli "
                    if "deu"in self.label.text:
                        a += "banyak "
                    if "dewek" in self.label.text:
                        a = a.replace("dewek", '')
                        a += "sendiri/diri "
                    if "di" in self.label.text:
                        a = a.replace("di", '')
                        a += "yang/sana "
                    if "di tuei suang" in self.label.text:
                        a = a.replace("tuei suang", '')
                        a += "tertua "
                    if "didik" in self.label.text:
                        a = a.replace("didik", '')
                        a += "sedikit "
                    if "diem" in self.label.text:
                        a = a.replace("diem", '')
                        a += "diam/tinggal "
                    if "dikup" in self.label.text:
                        a = a.replace("dikup", '')
                        a += "seorang/seekor "
                    if "dipe" in self.label.text:
                        a = a.replace("dipe", '')
                        a += "yang mana "
                    if "diye" in self.label.text:
                        a = a.replace("diye", '')
                        a += "yang ini "
                    if "do" in self.label.text:
                        a = a.replace("do", '')
                        if not "udo" in self.label.text and not "tidoa" in self.label.text and not "doloi" in self.label.text:
                            a = a.replace("udo", '')
                            a += "satu/1 "

                    if "doloi" in self.label.text:
                        a = a.replace("doloi", '')
                        a += "jauh di sana "
                    if "doo ba" in self.label.text:
                        a = a.replace("doo ba", '')
                        a += "itulah "
                    if "duei" in self.label.text:
                        a = a.replace("duei", '')
                        a += "dua/2 "
                    if "ebes" in self.label.text:
                        a = a.replace("ebes", '')
                        a += "rotan "
                    if "jang" in self.label.text:
                        a = a.replace("jang", '')
                        a += "rejang "
                    if "em ie" in self.label.text:
                        a = a.replace("em ie", '')
                        a += "perempuan tua "
                    if "em in" in self.label.text:
                        a = a.replace("em in", '')
                        a += "membawa "
                    if "em uk" in self.label.text:
                        a = a.replace("em uk", '')
                        a += "makan "
                    if "gacang gacang" in self.label.text:
                        a = a.replace("gacang gacang", '')
                        a += "cepat cepat "
                    if "galak" in self.label.text:
                        a = a.replace("galak", '')
                        a += "suka "
                    if "gelea" in self.label.text:
                        a = a.replace("gelea", '')
                        a += "giliran "
                    if "gematung" in self.label.text:
                        a = a.replace("gematung", '')
                        a += "menggantung "
                    if "gemit" in self.label.text:
                        a = a.replace("gemit", '')
                        a += "mengganti "
                    if "gemurek" in self.label.text:
                        a = a.replace("gemurek", '')
                        a += "menggangu "
                    if "genjano" in self.label.text:
                        a = a.replace("genjano", '')
                        a += "untuk apa "
                    if "genjano?" in self.label.text:
                        a = a.replace("genjano?", '')
                        a += "untuk apa? "
                    if "genkem'uk" in self.label.text:
                        a = a.replace("genkem'uk", '')
                        a += "bahan makanan "
                    if "genat" in self.label.text:
                        a = a.replace("genat", '')
                        a += "digantung "
                    if "genit" in self.label.text:
                        a = a.replace("genit", '')
                        a += "diganti "
                    if "genye" in self.label.text:
                        a = a.replace("genye", '')
                        a += "puas/bosan "
                    if "gerot" in self.label.text:
                        a = a.replace("gerot", '')
                        a += "gagah perkasa "
                    if "gi"in self.label.text:
                        a += "untuk/masih "
                    if "gidon" in self.label. text:
                        a = a.replace("gidon", '')
                        a += "sedang "
                    if "gitie" in self.label.text:
                        a = a.replace("gitie", '')
                        a += "diganti "
                    if "hai"in self.label.text:
                        a += "masalah "
                    if "hak"in self.label.text :

                        a += "harta "
                    if "ibo"in self.label.text :

                        a += "sedih "
                    if "iding" in self.label.text:
                        a = a.replace("iding", '')
                        a += "dekat "
                    if "idup" in self.label.text:
                        a = a.replace("idup", '')
                        a += "hidup "
                    if "ige"in self.label.text:
                        a += "terlalu "
                    if "igei" in self.label.text:
                        a = a.replace("igei", '')
                        a += "lagi "
                    if "ilmeu" in self.label.text:
                        a = a.replace("ilmeu", '')
                        a += "ilmu "
                    if "imuo" in self.label.text:
                        a = a.replace("imuo", '')
                        a += "harimau "
                    if "in'ok" in self.label.text:
                        a = a.replace("in'ok", '')
                        a += "ibu "
                    if "ipe"in self.label.text:
                        a = a.replace("ipe", '')
                        a += "mana "
                    if "isei" in self.label.text:
                        a = a.replace("isei", '')
                        a += "isi "
                    if "iso"in self.label.text:
                        a += "bukan "
                    if "ite"in self.label.text :

                        a += "kita "
                    if "jako" in self.label.text:
                        a = a.replace("jako", '')
                        a += "batas/sampai "
                    if "jam'eu" in self.label.text:
                        a = a.replace("jam'eu", '')
                        a += "jambu "
                    if "janje" in self.label.text:
                        a = a.replace("janje", '')
                        a += "janji/syarat "  
                    if "jano" in self.label.text:
                        a = a.replace("jano", '')
                        a += "apa "  
                    if "jano kelak ne" in self.label.text:
                        a = a.replace("kelak ne", '')
                        a += "apa yang diinginkan nya "
                    if "jatun" in self.label.text:
                        a = a.replace("jatun", '')
                        a += "jantung "  
                    if "jekun" in self.label.text:
                        a = a.replace("jekun", '')
                        a += "bendungan "  
                    if "jemago" in self.label.text:
                        a = a.replace("jemago", '')
                        a += "menjaga "  
                    if "jemawab" in self.label.text:
                        a = a.replace("jemawab", '')
                        a += "menjawab "  
                    if "jemuoa" in self.label.text:
                        a = a.replace("jemuoa", '')
                        a += "menjual "  
                    if "jengik" in self.label.text:
                        a = a.replace("jengik", '')
                        a += "benci/iri "   
                    if "jibeak" in self.label.text:
                        a = a.replace("jibeak", '')
                        a += "jangan jangan "  
                    if "ki'et" in self.label.text:
                        a = a.replace("ki'et", '')
                        a += "kuburan "  
                    if "jijei" in self.label.text:
                        a = a.replace("jijei", '')
                        a += "jadi "  
                    if "jisanak" in self.label.text:
                        a = a.replace("jisanak", '')
                        a += "kakak "  
                    if "juadeak" in self.label.text:
                        a = a.replace("juadeak", '')
                        a += "bekal "
                    if "kaben" in self.label.text:
                        a = a.replace("kaben", '')
                        a += "teman/rombongan "  
                    if "kacea" in self.label.text:
                        a = a.replace("kacea", '')
                        a += "kancil "  
                    if "kagen" in self.label.text:
                        a = a.replace("kagen", '')
                        a += "leher "  
                    if "kak"in self.label.text:
                        a += "kuli/pihak "
                    if "kak d" in self.label.text:
                        a = a.replace("kak d", '')
                        a += "pihak sana "  
                    if "kak yo" in self.label.text:
                        a = a.replace("kak yo", '')
                        a += "pihak sini "  
                    if "kakok" in self.label.text:
                        a = a.replace("kakok", '')
                        a += "kerja "  
                    if "kaleu" in self.label.text:
                        a = a.replace("kaleu", '')
                        a += "kalau "  
                    if "kam'ing" in self.label.text:
                        a = a.replace("kam'ing", '')
                        a += "kambing "  
                    if "kan"in self.label.text:
                        if not "makan" in self.label.text:
                            a = a.replace("mak an", '')
                            a += "ikan "  

                    if "kapes" in self.label.text:
                        a = a.replace("kapes", '')
                        a += "katun "  
                    if "kea"in self.label.text:
                        a += "lantai " 
                    if "kebaes" in self.label. text:
                        a = a.replace("kebaes", '')
                        a += "alangkah indah "  
                    if "kecek" in self.label.text:
                        a = a.replace("kecek", '')
                        a += "kata "  
                    if "kedelas" in self.label.text:
                        a = a.replace("kedelas", '')
                        a += "cepat cepat "  
                    if "kegerot" in self.label.text:
                        a = a.replace("kegerot", '')
                        a += "keperkasaan "  
                    if "ke'in" in self.label.text:
                        a = a.replace("ke'in", '')
                        a += "kering "  
                    if "kejei" in self.label.text:
                        a = a.replace("kejei", '')
                        a += "kejei "  
                    if "kejijei" in self.label.text:
                        a = a.replace("kejijei", '')
                        a += "kejadian/sekeliling "  
                    if "kekea" in self.label.text:
                        a = a.replace("kekea", '')
                        a += "kaki "  
                    if "kelak" in self.label.text:
                        a = a.replace("kelak", '')
                        a += "keinginan/cita-cita " 
                    if "keleak" in self.label.text:
                        a = a.replace("keleak", '')
                        a += "lihat "  
                    if "kelei" in self.label.text:
                        a = a.replace("kelei", '')
                        a += "sebesar "  
                    if "keloak" in self.label.text:
                        a = a.replace("keloak", '')
                        a += "suruhlah "  
                    if "kelwang" in self.label.text:
                        a = a.replace("kelwang", '')
                        a += "kaleng "  
                    if "kemak" in self.label.text:
                        a = a.replace("kemak", '')
                        a += "ambilah "
                    if "keme" in self.label.text:
                        a = a.replace("keme", '')
                        a += "kami "  
                    if "kemelbak" in self.label.text:
                        a = a.replace("kemelbak", '')
                        a += "terlalu "  
                    if "kemerjo" in self.label.text:
                        a = a.replace("kemerjo", '')
                        a += "mengerjakan "  
                    if "kemian" in self.label.text:
                        a = a.replace("kemian", '')
                        a += "pedulikan "  
                    if "kem'in" in self.label.text:
                        a = a.replace("kem'in", '')
                        a += "bawalah/ambilah "  
                    if "kemoboa" in self.label.text:
                        a = a.replace("kemoboa", '')
                        a += "menguburkan "  
                    if "kemten" in self.label.text:
                        a = a.replace("kemten", '')
                        a += "memperlihatkan "  
                    if "ken'ak" in self.label.text:
                        a = a.replace("ken'ak", '')
                        a += "dibuka "  
                    if "keleak" in self.label.text:
                        a = a.replace("keleak", '')
                        a += "dilihat "  
                    if "kenoboa" in self.label.text:
                        a = a.replace("kenoboa", '')
                        a += "dikuburkan "  
                    if "kenyang" in self.label.text:
                        a = a.replace("kenyang", '')
                        a += "kenyang "  
                    if "kepac" in self.label.text:
                        a = a.replace("kepac", '')
                        a += "keterampila/keahlia n "
                    if "kerang ba" in self.label.text:
                        a = a.replace("kerang ba", '')
                        a += "perangilah "  
                    if "kerno" in self.label.text:
                        a = a.replace("kerno", '')
                        a += "karna "  
                    if "kesak" in self.label.text:
                        a = a.replace("kesak", '')
                        a += "masak "  
                    if "kesele" in self.label.text:
                        a = a.replace("kesele", '')
                        a += "aneh sekali "  
                    if "kete" in self.label.text:
                        a = a.replace("kete", '')
                        a += "semua "  
                    if "keten" in self.label.text:
                        a = a.replace("keten", '')
                        a += "kelihatan "  
                    if "ketleu" in self.label.text:
                        a = a.replace("ketleu", '')
                        a += "yang ketiga "  
                    if "ke'un" in self.label.text:
                        a = a.replace("ke'un", '')
                        a += "kurung/nantinya "  
                    if "kinai" in self.label.text:
                        a = a.replace("kinai", '')
                        a += "mohon "  
                    if "kinget" in self.label.text:
                        a = a.replace("kinget", '')
                        a += "teringat "  
                    if "korok yo" in self.label.text:
                        a = a.replace("korok yo", '')
                        a += "sekitar sini "  
                    if "kuang ajea" in self.label.text:
                        a = a.replace("kuang ajea", '')
                        a += "kurang ajar "  
                    if "kucin" in self.label.text:
                        a = a.replace("kucin", '')
                        a += "kucing "  
                    if "kudo" in self.label.text:
                        a = a.replace("kudo", '')
                        a += "kuda "  
                    if "kulo" in self.label.text:
                        a = a.replace("kulo", '')
                        a += "jugo "  
                    if "kumu" in self.label.text:
                        a = a.replace("kumu", '')
                        a += "baginda "  
                    if "kunai" in self.label.text:
                        a = a.replace("kunai", '')
                        a += "dari "  
                    if "kun'eu" in self.label.text:
                        a = a.replace("kun'eu", '')
                        a += "derajat/tingkat "   
                    if "kuyuk" in self.label.text:
                        a = a.replace("kuyuk", '')
                        a += "anjing "  
                    if "laher" in self.label.text:
                        a = a.replace("laher", '')
                        a += "lahir "  
                    if "lai"in self.label.text:
                        a += "helai " 
                    if "sehingga" in self.label.text:
                        a = a.replace("sehingga", '')
                        a += "sehingga "  
                    if "hendak" in self.label.text:
                        a = a.replace("hendak", '')
                        a += "hendak "  
                    if "lak"in self.label.text:
                        a += "mau " 
                    if "lak mai ipe" in self.label.text:
                        a = a.replace("mai ipe", '')
                        a += "mau kemana "  
                    if "lalan" in self.label.text:
                        a = a.replace("lalan", '')
                        a += "lalang "  
                    if "lang uk" in self.label.text:
                        a = a.replace("lang uk", '')
                        a += "sombong angkuh "   
                    if "lapen" in self.label.text:
                        a = a.replace("lapen", '')
                        a += "sayur sayuran gulai " 
                    if "lat"in self.label.text:
                        a += "jejak " 
                    if "lebeak" in self.label. text:
                        a = a.replace("lebeak", '')
                        a += "lebih "  
                    if "lebeak baik" in self.label.text:
                        a = a.replace("lebeak baik", '')
                        a += "lebih baik "  
                    if "le'et" in self.label.text:
                        a = a.replace("le'et", '')
                        a += "baris "  
                    if "lem"in self.label.text:
                        a += "dalam " 
                    if "lemen" in self.label.text:
                        a = a.replace("lemen", '')
                        a += "plafon "  
                    if "lemeu" in self.label.text:
                        a = a.replace("lemeu", '')
                        a += "jeruk "  
                    if "lemo" in self.label.text:
                        a = a.replace("lemo", '')
                        a += "lima/5 "  
                    if "lepas" in self.label.text:
                        a = a.replace("lepas", '')
                        a += "lepas/bebas "  
                    if "leyen" in self.label.text:
                        a = a.replace("leyen", '')
                        a += "lain "  
                    if "libea" in self.label.text:
                        a = a.replace("libea", '')
                        a += "lebar "  
                    if "licin" in self.label.text:
                        a = a.replace("licin", '')
                        a += "licin "  
                    if "lie"in self.label.text:
                        a += "beri " 
                    if "limeu" in self.label.text:
                        a = a.replace("limeu", '')
                        a += "tersesat "  
                    if "limeu dalen" in self.label.text:
                        a = a.replace("limeu dalen", '')
                        a += "tersesat di jalan "  
                    if "ling is" in self.label.text:
                        a = a.replace("ling is", '')
                        a += "linggis "  
                    if "lu us" in self.label.text:
                        a = a.replace("lu us", '')
                        a += "lurus "  
                    if "luea" in self.label.text:
                        a = a.replace("luea", '')
                        a += "luar "  
                    if "lut"in self.label.text:
                        a += "sekali "  
                    if "macoa" in self.label.text:
                        a = a.replace("macoa", '')
                        a += "mancur "  
                    if "madep" in self.label.text:
                        a = a.replace("madep", '')
                        a += "menghadap "  
                    if "megea" in self.label.text:
                        a = a.replace("megea", '')
                        a += "kepada "  
                    if "magea" in self.label.text:
                        a = a.replace("magea", '')
                        a += "mendatangi "  
                    if "mai"in self.label.text:
                        a += "ke " 
                    if "majak" in self.label.text:
                        a = a.replace("majak", '')
                        a += "mengajak "  
                    if "majea" in self.label.text:
                        a = a.replace("majea", '')
                        a += "mengajar "  
                    if "maju" in self.label.text:
                        a = a.replace("maju", '')
                        a += "terhadap "  
                    if "mak"in self.label.text:
                        if not "makan" in self.value.text and not "mako" in self.value.text and not "maksut" in self.value.text and not "maka" in self.label.text:
                            a = a.replace("mak a", '')
                            a += "mengambil "  

                    if "maie" in self.label.text:
                        a = a.replace("maie", '')
                        a += "panggil "  
                    if "mako" in self.label.text:
                        a = a.replace("mako", '')
                        a += "supaya/sehingga "  
                    if "maksut" in self.label.text:
                        a = a.replace("maksut", '')
                        a += "maksud "
                    if "malau" in self.label.text:
                        a = a.replace("malau", '')
                        a += "menghalau "  
                    if "mem'ung" in self.label.text:
                        a = a.replace("mem'ung", '')
                        a += "membuang "  
                    if "manat" in self.label.text:
                        a = a.replace("manat", '')
                        a += "amanat "  
                    if "mang us" in self.label.text:
                        a = a.replace("mang us", '')
                        a += "manggis "  
                    if "man un" in self.label.text:
                        a = a.replace("man un", '')
                        a += "mendatangi/berperang "
                    if "maro" in self.label.text:
                        a = a.replace("maro", '')
                        a += "mari "  
                    if "maso" in self.label.text:
                        a = a.replace("maso", '')
                        a += "mustahil "  
                    if "matie" in self.label.text:
                        a = a.replace("matie", '')
                        a += "mati/meninggal/meni nggal dunia "
                    if "mebureu" in self.label.text:
                        a = a.replace("mebureu", '')
                        a += "berburu "  
                    if "mebut" in self.label.text:
                        a = a.replace("mebut", '')
                        a += "merebut "  
                    if "mecem" in self.label.text:
                        a = a.replace("mecem", '')
                        a += "bermacam macam "   
                    if "mecik" in self.label.text:
                        a = a.replace("mecik", '')
                        a += "menyirami "  
                    if "medas" in self.label.text:
                        a = a.replace("medas", '')
                        a += "masuk rumah "  
                    if "medek" in self.label.text:
                        a = a.replace("medek", '')
                        a += "hulu "  
                    if "medin" in self.label.text:
                        a = a.replace("medin", '')
                        a += "merasa pedih "  
                    if "meduo" in self.label.text:
                        a = a.replace("meduo", '')
                        a += "memanggil "  
                    if "megep" in self.label.text:
                        a = a.replace("megep", '')
                        a += "memeluk "  
                    if "megon" in self.label.text:
                        a = a.replace("megon", '')
                        a += "memegang "  
                    if "mekak" in self.label.text:
                        a = a.replace("mekak", '')
                        a += "memekakan "  
                    if "meker" in self.label.text:
                        a = a.replace("meker", '')
                        a += "berpikir "  
                    if "melarat" in self.label.text:
                        a = a.replace("melarat", '')
                        a += "mengembara "  
                    if "melie" in self.label.text:
                        a = a.replace("melie", '')
                        a += "memberi "  
                    if "melie namen" in self.label.text:
                        a = a.replace("melie namen", '')
                        a += "memberi nama "  
                    if "mengacap" in self.label.text:
                        a = a.replace("mengacap", '')
                        a += "lari "  
                    if "melitas" in self.label.text:
                        a = a.replace("melitas", '')
                        a += "lewat "  
                    if "meloak" in self.label.text:
                        a = a.replace("meloak", '')
                        a += "suruh "  
                    if "meluk" in self.label.text:
                        a = a.replace("meluk", '')
                        a += "melempar "  
                    if "memana" in self.label.text:
                        a = a.replace("memana", '')
                        a += "memanah "  
                    if "meman" in self.label.text:
                        a = a.replace("meman", '')
                        a += "memang "  
                    if "menea" in self.label.text:
                        a = a.replace("menea", '')
                        a += "membuat "  
                    if "men'es" in self.label.text:
                        a = a.replace("men'es", '')
                        a += "menemani "  
                    if "mengacap" in self.label.text:
                        a = a.replace("mengacap", '')
                        a += "lari "  
                    if "mengamuk" in self.label.text:
                        a = a.replace("mengamuk", '')
                        a += "mengamuk "  
                    if "menge" in self.label.text:
                        a = a.replace("menge", '')
                        a += "makan "  
                    if "menge in kik" in self.label.text:
                        a = a.replace("in kik", '')
                        a += "mencari "  
                    if "mengin'oi/" in self.label.text:
                        a = a.replace("oi/", '')
                        a += "menangis "  
                    if "menim'ak" in self.label.text:
                        a = a.replace("menim'ak", '')
                        a += "menembak "  
                    if "menusyo" in self.label.text:
                        a = a.replace("menusyo", '')
                        a += "manusia "  
                    if "menyiep" in self.label.text:
                        a = a.replace("menyiep", '')
                        a += "siap siap "   
                    if "mepek" in self.label.text:
                        a = a.replace("mepek", '')
                        a += "menaruh/meletakan "  
                    if "mepuk" in self.label.text:
                        a = a.replace("mepuk", '')
                        a += "mencuci "  
                    if "meran" in self.label.text:
                        a = a.replace("meran", '')
                        a += "memerangi "  
                    if "mesak" in self.label.text:
                        a = a.replace("mesak", '')
                        a += "masak "  
                    if "mesoa" in self.label.text:
                        a = a.replace("mesoa", '')
                        a += "mencari "  
                    if "meto" in self.label.text:
                        a = a.replace("meto", '')
                        a += "jalan jalan "  
                    if "midup" in self.label.text:
                        a = a.replace("midup", '')
                        a += "memelihara "  
                    if "mie"in self.label.text:
                        a += "nasi " 
                    if "mileu" in self.label.text:
                        a = a.replace("mileu", '')
                        a += "mengikuti/ikut "   
                    if "milin" in self.label.text:
                        a = a.replace("milin", '')
                        a += "berbicara "  
                    if "milot" in self.label.text:
                        a = a.replace("milot", '')
                        a += "memelihara "  
                    if "mimak" in self.label.text:
                        a = a.replace("mimak", '')
                        a += "menghina "  
                    if "mim'ang" in self.label.text:
                        a = a.replace("mim'ang", '')
                        a += "mengintip "  
                    if "m'in" in self.label.text:
                        a = a.replace("m'in", '')
                        a += "membawa "  
                    if "min'a" in self.label.text:
                        a = a.replace("min'a", '')
                        a += "ke sana "  
                    if "min as" in self.label.text:
                        a = a.replace("min as", '')
                        a += "ke atas "  
                    if "min i" in self.label.text:
                        a = a.replace("min i", '')
                        a += "kesana "  
                    if "minoa" in self.label.text:
                        a = a.replace("minoa", '')
                        a += "bocor "  
                    if "misal" in self.label.text:
                        a = a.replace("misal", '')
                        a += "misal "  
                    if "misal ne" in self.label.text:
                        a = a.replace("misal ne", '')
                        a += "misalnya "  
                    if "mogoa" in self.label.text:
                        a = a.replace("mogoa", '')
                        a += "terus menerus "  
                    if "mojoa" in self.label.text:
                        a = a.replace("mojoa", '')
                        a += "mujur "  
                    if "monoak" in self.label.text:
                        a = a.replace("monoak", '')
                        a += "membunuh "  
                    if "monok" in self.label.text:
                        a = a.replace("monok", '')
                        a += "ayam "  
                    if "monot" in self.label.text:
                        a = a.replace("monot", '')
                        a += "hanya "
                    if "muang" in self.label.text:
                        a = a.replace("muang", '')
                        a += "membuang "   
                    if "mukak" in self.label.text:
                        a = a.replace("mukak", '')
                        a += "bukalah "  
                    if "mukus" in self.label.text:
                        a = a.replace("mukus", '')
                        a += "membungkus "  
                    if "mulai" in self.label.text:
                        a = a.replace("mulai", '')
                        a += "mulai "  
                    if "najea" in self.label.text:
                        a = a.replace("najea", '')
                        a += "mengerjakan "  
                    if "nak"in self.label.text:
                        a += "di " 
                    if "nalau" in self.label.text:
                        a = a.replace("nalau", '')
                        a += "dihalau "  
                    if "nam"in self.label.text:
                        a += "bisa " 
                    if "namen" in self.label.text:
                        a = a.replace("namen", '')
                        a += "tahu/mengetahui "  
                    if "nano" in self.label.text:
                        a = a.replace("nano", '')
                        a += "tadi "  
                    if "napag" in self.label.text:
                        a = a.replace("napag", '')
                        a += "kawin "  
                    if "natin" in self.label.text:
                        a = a.replace("natin", '')
                        a += "dilotong "  
                    if "nebut" in self.label.text:
                        a = a.replace("nebut", '')
                        a += "direbut "  
                    if "necik" in self.label.text:
                        a = a.replace("necik", '')
                        a += "dipercik "  
                    if "negon" in self.label.text:
                        a = a.replace("negon", '')
                        a += "dipegong "  
                    if "negre" in self.label.text:
                        a = a.replace("negre", '')
                        a += "kerajaan "  
                    if "neket" in self.label.text:
                        a = a.replace("neket", '')
                        a += "diikat "  
                    if "nenge" in self.label.text:
                        a = a.replace("nenge", '')
                        a += "dimarahi "  
                    if "ngako in k" in self.label.text:
                        a = a.replace("in k", '')
                        a += "mengetahui "  
                    if "ngecacak" in self.label.text:
                        a = a.replace("ngecacak", '')
                        a += "menetes "  
                    if "ngen" in self.label.text:
                        if not "coa si angen" :
                            a = a.replace("ngen", '')

                            a += "dengan " 
                    if "ngen baik" in self.label.text:
                        if not "coa si angen" :
                            a = a.replace("ngen baik", '')

                            a += "dengan baik " 
                    if "ngota" in self.label.text:
                        a = a.replace("ngota", '')
                        a += "bercakap cakap/ngobrol "
                    if "nidik" in self.label.text:
                        a = a.replace("nidik", '')
                        a += "dibidik "  
                    if "nien" in self.label.text:
                        a = a.replace("nien", '')
                        a += "sekali "   
                    if "nikeak" in self.label.text:
                        a = a.replace("nikeak", '')
                        a += "nikah "  
                    if "ninik" in self.label.text:
                        a = a.replace("ninik", '')
                        a += "kakek/nenek "  
                    if "nogoa" in self.label.text:
                        a = a.replace("nogoa", '')
                        a += "terus menerus "  
                    if "nomor" in self.label.text:
                        a = a.replace("nomor", '')
                        a += "nomor "  
                    if "nonot" in self.label.text:
                        a = a.replace("nonot", '')
                        a += "dihanyut "  
                    if "nu" in self.label.text:
                        a = a.replace("nu", '')
                        a += "mu "  
                    if "nukus" in self.label.text:
                        a = a.replace("nukus", '')
                        a += "dibungkus "  
                    if "nun'ak" in self.label.text:
                        a = a.replace("nun'ak", '')
                        a += "dicampur  "
                    if "nyut" in self.label.text:
                        a = a.replace("nyut", '')
                        a += "niat "  
                    if "o" in self.label.text:
                        if not "keracok" in self.value.text and not "oak"in self.label.text and not "sengok" in self.value.text and not "do" in self.value.text and not "coa" in self.value.text and not "loteng" in self.value.text and not "pencoak" in self.label.text:
                            g = self.label.text
                            g = g.replace("o", "itu")
                            self.label.text = g
                    if"oak"in self.label.text:
                        if not "asoak" in self.label.text:
                            a = a.replace("oak","jauh")

                    if "pacak" in self.label. text:
                        a = a.replace("pacak", '')
                        a += "pandai/terampil "      
                    if "pacoa" in self.label.text:
                        a = a.replace("pacoa", '')
                        a += "pancuran "  
                    if "pedeak" in self.label.text:
                        a = a.replace("pedeak", '')
                        a += "alangkah hebat "  
                    if "padék" in self.label.text:
                        a = a.replace("padék", '')
                        a += "baik "
                    if "pageu" in self.label.text:
                        a = a.replace("pageu", '')
                        a += "loteng "  
                    if "pakei" in self.label.text:
                        a = a.replace("pakei", '')
                        a += "memakai "  
                    if "pakie" in self.label.text:
                        a = a.replace("pakie", '')
                        a += "keahlian/ilmu "  
                    if "palin" in self.label.text:
                        a = a.replace("palin", '')
                        a += "paling "  
                    if "panes" in self.label.text:
                        a = a.replace("panes", '')
                        a += "panas "  
                    if "papa" in self.label.text:
                        a = a.replace("papa", '')
                        a += "wajah "  
                    if "par'au" in self.label.text:
                        a = a.replace("par'au", '')
                        a += "parau "  
                    if "pecoak" in self.label.text:
                        a = a.replace("pecoak", '')
                        a += "pecah "  
                    if "pegas" in self.label.text:
                        a = a.replace("pegas", '')
                        a += "sampah "  
                    if "pek"in self.label.text:
                        a += "taruh/meletakan " 
                    if "peker" in self.label.text:
                        a = a.replace("peker", '')
                        a += "pékér "  
                    if "pekue" in self.label.text:
                        a = a.replace("pekue", '')
                        a += "kelakua "  
                    if "pelge" in self.label.text:
                        a = a.replace("pelge", '')
                        a += "pedas "  
                    if "pemanuo" in self.label.text:
                        a = a.replace("pemanuo", '')
                        a += "tujuan/arah "  
                    if "penan" in self.label.text:
                        a = a.replace("penan", '')
                        a += "tempat "  
                    if "pengleak" in self.label.text:
                        a = a.replace("pengleak", '')
                        a += "pemandangan "  
                    if "pengelie" in self.label.text:
                        a = a.replace("pengelie", '')
                        a += "hadiah "  
                    if "penmeu" in self.label.text:
                        a = a.replace("penmeu", '')
                        a += "temuan "  
                    if "penyebit" in self.label.text:
                        a = a.replace("penyebit", '')
                        a += "bersedih "  
                    if "penyiep" in self.label.text:
                        a = a.replace("penyiep", '')
                        a += "pembersih/penyiep "
                    if "penyudo" in self.label.text:
                        a = a.replace("penyudo", '')
                        a += "akhirnya "  
                    if "peran" in self.label.text:
                        a = a.replace("peran", '')
                        a += "perang "  
                    if "pesen" in self.label.text:
                        a = a.replace("pesen", '')
                        a += "pesan "  
                    if "petei" in self.label.text:
                        a = a.replace("petei", '')
                        a += "peti "  
                    if "petus" in self.label.text:
                        a = a.replace("petus", '')
                        a += "palu "  
                    if "pidik" in self.label.text:
                        a = a.replace("pidik", '')
                        a += "jitu "  
                    if "ping'an" in self.label.text:
                        a = a.replace("ping'an", '')
                        a += "piring "  
                    if "pisan" in self.label.text:
                        a = a.replace("pisan", '')
                        a += "pisang "  
                    if "piset" in self.label.text:
                        a = a.replace("piset", '')
                        a += "bungsu "  
                    if "pisuo" in self.label.text:
                        a = a.replace("pisuo", '')
                        a += "pisau "  
                    if "pitat" in self.label.text:
                        a = a.replace("pitat", '')
                        a += "parang "  
                    if "piyo" in self.label.text:
                        a = a.replace("piyo", '')
                        a += "sini "  
                    if "pogoa" in self.label.text:
                        a = a.replace("pogoa", '')
                        a += "terus menerus "  
                    if "pokok" in self.label.text:
                        a = a.replace("pokok", '')
                        a += "pokok "  
                    if "polok" in self.label.text:
                        a = a.replace("polok", '')
                        a += "puluh "  
                    if "pon'o in k" in self.label.text:
                        a = a.replace("in k", '')
                        a += "pondok "  
                    if "puea" in self.label.text:
                        a = a.replace("puea", '')
                        a += "puar "  
                    if "pun"in self.label.text:
                        a += "pohon " 
                    if "putus" in self.label.text:
                        a = a.replace("putus", '')
                        a += "putus "  
                    if "raes" in self.label.text:
                        a = a.replace("raes", '')
                        a += "hiasi "  
                    if "rajo" in self.label.text:
                        a = a.replace("rajo", '')
                        a += "raja "  
                    if "rami" in self.label.text:
                        a = a.replace("rami", '')
                        a += "ramai "  
                    if "ra'yat" in self.label.text:
                        a = a.replace("ra'yat", '')
                        a += "rakyat "  
                    if "renyeng" in self.label.text:
                        a = a.replace("renyeng", '')
                        a += "pusing "  
                    if "gembira" in self.label.text:
                        a = a.replace("gembira", '')
                        a += "riang "  
                    if "sadar" in self.label.text:
                        a = a.replace("sadar", '')
                        a += "sadar "  
                    if "sa'ie" in self.label.text:
                        a = a.replace("sa'ie", '')
                        a += "suara "  
                    if "sak"in self.label.text :
                        a = a.replace("sak", '')
                        b = ["sejak ", "kecewa "]
                        a += random.choice(b)
                    if "sakit" in self.label.text:
                        a = a.replace("sakit ", '')
                        a += "sakit "  
                    if "sako" in self.label.text:
                        a = a.replace("sako", '')
                        a += "sangka "  
                    if "sakut" in self.label.text:
                        a = a.replace("sakut", '')
                        a += "tersangkut "  
                    if "saleak" in self.label.text:
                        a = a.replace("saleak", '')
                        a += "kesalahan "  
                    if "samo" in self.label.text:
                        a = a.replace("samo", '')
                        a += "sama "  
                    if "sapei" in self.label.text:
                        a = a.replace("sapei", '')
                        a += "sapi "  
                    if "sapie" in self.label.text:
                        a = a.replace("sapie", '')
                        a += "sampai "  
                    if "sarat" in self.label.text:
                        a = a.replace("sarat", '')
                        a += "syarat "  
                    if "sauk" in self.label.text:
                        a = a.replace("sauk", '')
                        a += "tanguk "  
                    if "sayan" in self.label.text:
                        a = a.replace("sayan", '')
                        a += "sayang "  
                    if "seak" in self.label.text:
                        a = a.replace("seak", '')
                        a += "berangkat "  
                    if "sebap" in self.label.text:
                        a = a.replace("sebap", '')
                        a += "sebab "
                    if "sebit" in self.label.text:
                        a = a.replace("sebit", '')
                        a += "bersedih "  
                    if "sebit" in self.label.text:
                        a = a.replace("sebit", '')
                        a += "sedih "  
                    if "secao" in self.label.text:
                        a = a.replace("secao", '')
                        a += "secara "  
                    if "selaw" in self.label.text:
                        a = a.replace("selaw", '')
                        a += "perempuan "  
                    if "seleg" in self.label.text:
                        a = a.replace("seleg", '')
                        a += "malu/tersinggung "  
                    if "seman" in self.label.text:
                        a = a.replace("seman", '')
                        a += "laki laki "  
                    if "semat" in self.label.text:
                        a = a.replace("semat", '')
                        a += "setan/siluman "
                    if "semelidik" in self.label.text:
                        a = a.replace("semelidik", '')
                        a += "menyelidiki/selidik "  
                    if "semergap" in self.label.text:
                        a = a.replace("semergap", '')
                        a += "sergap "  
                    if "semisit" in self.label.text:
                        a = a.replace("semisit", '')
                        a += "mengiris/menyakiti "
                    if "semsing" in self.label.text:
                        a = a.replace("semsing", '')
                        a += "meyising "  
                    if "semsung lat" in self.label.text:
                        a = a.replace("semsung lat", '')
                        a += "mengikuti jejak "  
                    if "semulen" in self.label.text:
                        a = a.replace("semulen", '')
                        a += "gadis "  
                    if "semupeu" in self.label.text:
                        a = a.replace("semupeu", '')
                        a += "menyapu "  
                    if "sena'" in self.label.text:
                        a = a.replace("sena'", '')
                        a += "diceraikan "  
                    if "senam ut" in self.label.text:
                        a = a.replace("senam ut", '')
                        a += "disambut/ditemukan "
                    if "gembira" in self.label.text:
                        a = a.replace("gembira", '')
                        a += "senang "  
                    if "senan" in self.label.text:
                        a = a.replace("senan", '')
                        a += "senang "  
                    if "seneak" in self.label.text:
                        a = a.replace("seneak", '')
                        a += "selera "   
                    if "senido" in self.label.text:
                        a = a.replace("senido", '')
                        a += "diperhatikan "  
                    if "senil" in self.label.text:
                        a = a.replace("senil", '')
                        a += "dilukai "  
                    if "senisit" in self.label.text:
                        a = a.replace("senisit", '')
                        a += "diiris "  
                    if "deium" in self.label.text:
                        a = a.replace("deium", '')
                        a += "dicium "  
                    if "sergayeu" in self.label.text:
                        a = a.replace("sergayeu", '')
                        a += "sergayu "  
                    if "serwa" in self.label.text:
                        a = a.replace("serwa", '')
                        a += "celana "  
                    if "si" in self.label.text:
                        a = a.replace("si", '')
                        if "siamang" in self.label.text:
                            a = a.replace("siamang", '')
                            a += "siamang "  

                        if "siap" in self.label.text:
                            a = a.replace("siap", '')
                            a += "bersiap "  

                        if "sifet" in self.label.text:
                            a = a.replace("sifet", '')
                            a += "sifat "  

                        if "sipan" in self.label.text:
                            a = a.replace("sipan", '')
                            a += "persimpangan "  

                        if "siut" in self.label.text:
                            a = a.replace("siut", '')
                            a += "iri "  

                        if "sini" in self.label.text:
                            a = a.replace("sini", '')
                            a += "dia/mereka "  

                    if "cuko" in self.label.text:
                        a = a.replace("cuko", '')
                        a += "cuka "  
                    if "suang" in self.label.text:
                        a = a.replace("suang", '')
                        a += "sendirian "  
                    if "sua'o" in self.label.text:
                        a = a.replace("sua'o", '')
                        a += "suara "  
                    if "sudo" in self.label.text:
                        a = a.replace("sudo", '')
                        a += "sudah "  
                    if "sugeak" in self.label.text:
                        a = a.replace("sugeak", '')
                        a += "kaya "  
                    if "tai"in self.label.text:
                        a += "mari " 
                    if "talan" in self.label.text:
                        a = a.replace("talan", '')
                        a += "talang "  
                    if "tam'e" in self.label.text:
                        a = a.replace("tam'e", '')
                        a += "bertambah "  
                    if "tangen" in self.label.text:
                        a = a.replace("tangen", '')
                        a += "tangan "  
                    if "tan ing" in self.label.text:
                        a = a.replace("tan ing", '')
                        a += "tanding "  
                    if "tan'o" in self.label.text:
                        a = a.replace("tan'o", '')
                        a += "tanda "  
                    if "tapie" in self.label.text:
                        a = a.replace("tapie", '')
                        a += "baru akan/sebelum "  
                    if "tawei" in self.label.text:
                        a = a.replace("tawei", '')
                        a += "tawa "  
                    if "te" in self.label.text:
                        a = a.replace("te", '')
                        a += "kita "  
                    if "teak" in self.label.text:
                        a = a.replace("teak", '')
                        a += "ayak "  
                    if "teak ba" in self.label.text:
                        a = a.replace("teak ba", '')
                        a += "entah "   
                    if "tebedan" in self.label.text:
                        a = a.replace("tebedan", '')
                        a += "terhenti "  
                    if "tebet" in self.label.text:
                        a = a.replace("tebet", '')
                        a += "bendungan "  
                    if "tebo" in self.label.text:
                        a = a.replace("tebo", '')
                        a += "bukit/gunung "  
                    if "tebo tepuk" in self.label.text:
                        a = a.replace("tebo tepuk", '')
                        a += "bukit tepuk "  
                    if "teje" in self.label.text:
                        a = a.replace("teje", '')
                        a += "berdiri tegak "  
                    if "tekem'uk" in self.label.text:
                        a = a.replace("tekem'uk", '')
                        a += "termakan "  
                    if "tekjir" in self.label.text:
                        a = a.replace("tekjir", '')
                        a += "tekejut "  
                    if "tekle" in self.label.text:
                        a = a.replace("tekle", '')
                        a += "terlihat "  
                    if "teko" in self.label.text:
                        a = a.replace("teko", '')
                        a += "datang "  
                    if "teko  in kaben yo keduei" in self.label.text:
                        a = a.replace("yo keduei", '')
                        a += "kembali untuk dua kali " 
                    if "tekujat" in self.label.text:
                        a = a.replace("tekujat", '')
                        a += "terkenal "  
                    if "teleu" in self.label.text:
                        a = a.replace("teleu", '')
                        a += "tiga "  
                    if "tema'" in self.label.text:
                        a = a.replace("tema'", '')
                        a += "menegur "  
                    if "temakep" in self.label.text:
                        a = a.replace("temakep", '')
                        a += "menangkap "  
                    if "temanang" in self.label.text:
                        a = a.replace("temanang", '')
                        a += "manu "  
                    if "tamanye" in self.label.text:
                        a = a.replace("tamanye", '')
                        a += "bertanya "  
                    if "temawei" in self.label.text:
                        a = a.replace("temawei", '')
                        a += "menertawakan "  
                    if "tem e" in self.label.text:
                        a = a.replace("tem e", '')
                        a += "menghina/merendahkan "
                    if "temeng'ek kudo" in self.label.text:
                        a = a.replace("ek kudo", '')
                        a += "menungang kuda "  
                    if "temeu" in self.label.text:
                        a = a.replace("temeu", '')
                        a += "temu "  
                    if "temgen" in self.label.text:
                        a = a.replace("temgen", '')
                        a += "menamakan "  
                    if "teming'a" in self.label.text:
                        a = a.replace("teming'a", '')
                        a += "tinggalkan "  
                    if "teming uk" in self.label.text:
                        a = a.replace("teming uk", '')
                        a += "mendengarkan "  
                    if "temleu" in self.label.text:
                        a = a.replace("temleu", '')
                        a += "peluru "  
                    if "temmeu" in self.label.text:
                        a = a.replace("temmeu", '')
                        a += "bertemu "  
                    if "temngoar" in self.label.text:
                        a = a.replace("temngoar", '')
                        a += "mendengarkan "  
                    if "temot" in self.label.text:
                        a = a.replace("temot", '')
                        a += "duduk "  
                    if "temmoa" in self.label.text:
                        a = a.replace("temmoa", '')
                        a += "menuruti/semua "  
                    if "temto in k" in self.label.text:
                        a = a.replace("in k", '')
                        a += "memotong "  
                    if "temuan" in self.label.text:
                        a = a.replace("temuan", '')
                        a += "mempunyai "  
                    if "temulung" in self.label.text:
                        a = a.replace("temulung", '')
                        a += "menolong "  
                    if "temun juk" in self.label.text:
                        a = a.replace("temun juk", '')
                        a += "menunjukan "  
                    if "menurunkan" in self.label.text:
                        a = a.replace("menurunkan", '')
                        a += "menurunkan "  
                    if "tenawei" in self.label.text:
                        a = a.replace("tenawei", '')
                        a += "ditertawakan "  
                    if "tengen" in self.label.text:
                        a = a.replace("tengen", '')
                        a += "kapan/dinamakan "  
                    if "tengoa" in self.label.text:
                        a = a.replace("tengoa", '')
                        a += "dengar "  
                    if "tenngoa " in self.label.text:
                        a = a.replace("tenngoa", '')
                        a += "didengar "  
                    if "tentara" in self.label.text:
                        a = a.replace("tentara", '')
                        a += "tentera "  
                    if "tepap" in self.label.text:
                        a = a.replace("tepap", '')
                        a += "bahan pakaian yang  dicuci "
                    if "tepeket" in self.label.text:
                        a = a.replace("tepeket", '')
                        a += "terikat "   
                    if "terus" in self.label.text:
                        a = a.replace("terus", '')
                        a += "terus "  
                    if "tidoa" in self.label.text:
                        a = a.replace("tidoa", '')
                        a = a.replace("tia", '')
                        a += "tidur "  
                    if "tilei" in self.label.text:
                        a = a.replace("tilei", '')
                        a += "tali "  
                    if "tim'ak" in self.label.text:
                        a = a.replace("tim'ak", '')
                        a += "tembak "  
                    if "ting'a" in self.label.text:
                        a = a.replace("ting'a", '')
                        a += "tinggal "  
                    if "tinget" in self.label.text:
                        a = a.replace("tinget", '')
                        a += "teringat "  
                    if "tip"in self.label.text:
                        a += "setiap " 
                    if "titik" in self.label.text:
                        a = a.replace("titik", '')
                        a += "kecil "  
                    if "ti'uk" in self.label.text:
                        a = a.replace("ti'uk", '')
                        a += "telinga "  
                    if "tobo o" in self.label.text:
                        a = a.replace("tobo o", '')
                        a += "mereka semua"  
                    if "tobo yo" in self.label.text:
                        a = a.replace("tobo yo", '')
                        a += "mereka ini "  
                    if "tokoa" in self.label.text:
                        a = a.replace("tokoa", '')
                        a += "beli "  
                    if "totoa" in self.label.text:
                        a = a.replace("totoa", '')
                        a += "turut "  
                    if "tuhan" in self.label.text:
                        a = a.replace("tuhan", '')
                        a += "tuhan "  
                    if "tukang kesak" in self.label.text:
                        a = a.replace("tukang kesak", '')
                        a += "koki "  
                    if "tukang mepuk ping'an" in self.label.text:
                        a = a.replace("ping'an", '')
                        a += "tukang cuci piring "  
                    if "tukang tepap" in self.label.text:
                        a = a.replace("tukang tepap", '')
                        a += "babu cuci "  
                    if "tulun" in self.label.text:
                        a = a.replace("tulun", '')
                        a += "tolong "  
                    if "tulung menulung" in self.label.text:
                        a = a.replace("tulung menulung", '')
                        a += "tolong-menolong "   
                    if "tun"in self.label.text:
                        a += "orang " 
                    if "tun masoa ebes" in self.label.text:
                        a = a.replace("masoa ebes", '')
                        a += "pencari rotan "  
                    if "tun nien" in self.label.text:
                        a = a.replace("tun nien", '')
                        a += "orang nian "  
                    if "tun titik" in self.label.text:
                        a = a.replace("tun titik", '')
                        a += "bayi "  
                    if "tu'un" in self.label.text:
                        a = a.replace("tu'un", '')
                        a += "turun "  
                    if "udi"in self.label.text:
                        a += "kalian " 
                    if "udo"in self.label.text :
                        if not "coa an udo" in self.label.text:
                            a = a.replace("an  udo", '')
                            a += "sudah "  

                    if "ujang" in self.label.text:
                        a = a.replace("ujang", '')
                        a += "Ujang "  
                    if "ujien" in self.label.text:
                        a = a.replace("ujien", '')
                        a += "ujian "  
                    if "ujung" in self.label.text:
                        a = a.replace("ujung", '')
                        a += "ujung "   
                    if "uleak" in self.label.text:
                        a = a.replace("uleak", '')
                        a += "pekerjaan "  
                    if "ules o" in self.label.text:
                        a = a.replace("ules o", '')
                        a += "rupanya "  
                    if "umeak" in self.label.text:
                        a = a.replace("umeak", '')
                        a += "rumah "  
                    if "umei" in self.label.text:
                        a = a.replace("umei", '')
                        a += "ladang "  
                    if "um'un" in self.label.text:
                        a = a.replace("um'un", '')
                        a += "acara pernikahan "  
                    if "upik" in self.label.text:
                        a = a.replace("upik", '')
                        a += "Upik "  
                    if "uso"in self.label.text:
                        a += "rusa " 
                    if "uyo"in self.label.text :

                        a += "sekarang " 
                    if "wai"in self.label.text :

                        a += "sebagaimana " 
                    if "wak"in self.label.text :

                        a += "wak/tante "
                    if "waktu" in self.label.text:
                        a = a.replace("waktu", '')
                        a += "wakteu "  
                    if "kidek" in self.label.text:
                        a = a.replace("kidek", '')
                        a += "buruk, jelek "
                    if "tnie" in self.label.text:
                        a = a.replace("tnie", '')
                        a += "perut "
                    if "imeu" in self.label.text:
                        a = a.replace("imeu", '')
                        a += "harimau "
                    if "dung" in self.label.text:
                        a = a.replace("dung ", '')
                        a += "ular "
                    if "lemeu" in self.label.text:
                        a = a.replace("lemeu ", '')
                        a += "jeruk"
                    if "beko" in self.label.text:
                        a = a.replace("beko ", '')
                        a += "nangka "
                    g = str(self.label.text)
        
            else:
                pass
            self.label.text = a

            self.rlabel.text = self.label.text
            kaganga = self.rlabel.text

            kaganga = kaganga.replace("nd","Dx")

            kaganga = kaganga.replace("mb","Bx")
            kaganga = kaganga.replace("nj","Jx")
            kaganga = kaganga.replace("ngg","Gx")
            kaganga = kaganga.replace("ngk","Qx")
            kaganga = kaganga.replace("nc","Cx")
            kaganga = kaganga.replace("nt","Tx")
            kaganga = kaganga.replace("mp","Px")
            kaganga = kaganga.replace("gh","qx")
            kaganga = kaganga.replace("ng","F")
            kaganga = kaganga.replace("n","N")
            kaganga = kaganga.replace("eak","K")
            kaganga = kaganga.replace("k","kx")
            kaganga = kaganga.replace("g","gx")
            kaganga = kaganga.replace("t","tx")
            kaganga = kaganga.replace("d","dx")
            kaganga = kaganga.replace("p","px")
            kaganga = kaganga.replace("b","bx")
            kaganga = kaganga.replace("m","M")
            kaganga = kaganga.replace("c","cx")
            kaganga = kaganga.replace("j","jx")
            kaganga = kaganga.replace("s","sx")
            kaganga = kaganga.replace("r","rx")
            kaganga = kaganga.replace("l","lx")
            kaganga = kaganga.replace("y","yx")
            kaganga = kaganga.replace("w","wx")
            kaganga = kaganga.replace("h","hx")
            kaganga = kaganga.replace("i","ia")
            kaganga = kaganga.replace("u","ua")
            kaganga = kaganga.replace("e","ea")
            kaganga = kaganga.replace("o","oa")
            kaganga = kaganga.replace("Ma","m")
            kaganga = kaganga.replace("Mia","im")
            kaganga = kaganga.replace("Mua","um")
            kaganga = kaganga.replace("Mea","em")
            kaganga = kaganga.replace("Moa","om")
            kaganga = kaganga.replace("mF", 'Fm')
            kaganga = kaganga.replace("imF", 'Fim')
            kaganga = kaganga.replace("umF", 'Fum')
            kaganga = kaganga.replace("emF", 'Fem')
            kaganga = kaganga.replace("omF", 'Fom')
            kaganga = kaganga.replace("MK", 'mK')
            kaganga = kaganga.replace("mN",'Nm')
            kaganga = kaganga.replace("imN",'Nmi')
            kaganga = kaganga.replace("umN",'Nmu')
            kaganga = kaganga.replace("emN",'Nme')
            kaganga = kaganga.replace("omN",'Nmo')
            kaganga = kaganga.replace("mM","Mm")
            kaganga = kaganga.replace("miM","Mim")
            kaganga = kaganga.replace("muM","Mum")
            kaganga = kaganga.replace("meM","Mem")
            kaganga = kaganga.replace("moM","Mom")
            kaganga = kaganga.replace("Na","n")
            kaganga = kaganga.replace("Ni","in")
            kaganga = kaganga.replace("Nu","un")
            kaganga = kaganga.replace("Ne","en")
            kaganga = kaganga.replace("No","on")
            kaganga = kaganga.replace("va","v")
            kaganga = kaganga.replace("vi","iv")
            kaganga = kaganga.replace("vu","uv")
            kaganga = kaganga.replace("ve","ev")
            kaganga = kaganga.replace("vo","ov")
            kaganga = kaganga.replace("Fa","f")
            kaganga = kaganga.replace("Fia","if")
            kaganga = kaganga.replace("Fua","uf")
            kaganga = kaganga.replace("Fea","ef")
            kaganga = kaganga.replace("Foa","of")
            kaganga = kaganga.replace("FK","fK")            
            kaganga = kaganga.replace("fN",'Nf')
            kaganga = kaganga.replace("ifN",'Nif')
            kaganga = kaganga.replace("ufN",'Nuf')
            kaganga = kaganga.replace("efN",'Nef')
            kaganga = kaganga.replace("ofN",'Nof')
            kaganga = kaganga.replace("fM","Mf")
            kaganga = kaganga.replace("ifM","Mif")
            kaganga = kaganga.replace("ufM","Muf")
            kaganga = kaganga.replace("efM","Mef")
            kaganga = kaganga.replace("ofM","Mof")
            kaganga = kaganga.replace("txa","t")
            kaganga = kaganga.replace("txia","it")
            kaganga = kaganga.replace("txua","ut")
            kaganga = kaganga.replace("txea","et")
            kaganga = kaganga.replace("txoa","ot")
            kaganga = kaganga.replace("tF","Ft")
            kaganga = kaganga.replace("itF","Fit")
            kaganga = kaganga.replace("utF","Fut")
            kaganga = kaganga.replace("etF","Fet")
            kaganga = kaganga.replace("otF","Fot")
            kaganga = kaganga.replace("txK", 'tK')
            kaganga = kaganga.replace("tN",'Nt')
            kaganga = kaganga.replace("tiN",'Nit')
            kaganga = kaganga.replace("tuN",'Nut')
            kaganga = kaganga.replace("teN",'Net')
            kaganga = kaganga.replace("toN",'Not')
            kaganga = kaganga.replace("tM","Mt")
            kaganga = kaganga.replace("itM","Mit")
            kaganga = kaganga.replace("utM","Mut")
            kaganga = kaganga.replace("etM","Met")
            kaganga = kaganga.replace("otM","Mot")
            kaganga = kaganga.replace("bxa","b")
            kaganga = kaganga.replace("bxia","ib")
            kaganga = kaganga.replace("bxua","ub")
            kaganga = kaganga.replace("bxea","eb")
            kaganga = kaganga.replace("bxoa","ob")
            kaganga = kaganga.replace("bF", 'Fb')
            kaganga = kaganga.replace("ibF", 'Fib')
            kaganga = kaganga.replace("ubF", 'Fub')
            kaganga = kaganga.replace("ebF", 'Feb')
            kaganga = kaganga.replace("obF", 'Fob')
            kaganga = kaganga.replace("bxK", 'bK')
            kaganga = kaganga.replace("bN",'Nb')
            kaganga = kaganga.replace("ibN",'Nib')
            kaganga = kaganga.replace("ubN",'Nub')
            kaganga = kaganga.replace("ebN",'Neb')
            kaganga = kaganga.replace("obN",'Nob')
            kaganga = kaganga.replace("bM","Mb")
            kaganga = kaganga.replace("ibM","Mib")
            kaganga = kaganga.replace("ubM","Mub")
            kaganga = kaganga.replace("ebM","Meb")
            kaganga = kaganga.replace("obM","Mob")
            kaganga = kaganga.replace("cxa","c")
            kaganga = kaganga.replace("cxia","ic")
            kaganga = kaganga.replace("cxua","uc")
            kaganga = kaganga.replace("cxea","ec")
            kaganga = kaganga.replace("cxoa","oc")
            kaganga = kaganga.replace("cF", 'Fc')
            kaganga = kaganga.replace("icF", 'Fic')
            kaganga = kaganga.replace("ucF", 'Fuc')
            kaganga = kaganga.replace("ecF", 'Fec')
            kaganga = kaganga.replace("ocF", 'Foc')
            kaganga = kaganga.replace("cxK", 'cK')
            kaganga = kaganga.replace("cN",'Nc')
            kaganga = kaganga.replace("icN",'Nic')
            kaganga = kaganga.replace("ucN",'Nuc')
            kaganga = kaganga.replace("ecN",'Nec')
            kaganga = kaganga.replace("ocN",'Noc')
            kaganga = kaganga.replace("cM","Mc")
            kaganga = kaganga.replace("icM","Mic")
            kaganga = kaganga.replace("ucM","Muc")
            kaganga = kaganga.replace("ecM","Mec")
            kaganga = kaganga.replace("ocM","Moc")
            kaganga = kaganga.replace("dxa","d")
            kaganga = kaganga.replace("dxia","id")
            kaganga = kaganga.replace("dxua","ud")
            kaganga = kaganga.replace("dxea","ed")
            kaganga = kaganga.replace("dxoa","od")
            kaganga = kaganga.replace("Fd", 'dF')
            kaganga = kaganga.replace("idF", 'Fid')
            kaganga = kaganga.replace("udF", 'Fud')
            kaganga = kaganga.replace("edF", 'Fed')
            kaganga = kaganga.replace("odF", 'Fod')
            kaganga = kaganga.replace("dxK", 'dK')
            kaganga = kaganga.replace("dN",'Nd')
            kaganga = kaganga.replace("idN",'Nid')
            kaganga = kaganga.replace("udN",'Nud')
            kaganga = kaganga.replace("edN",'Ned')
            kaganga = kaganga.replace("odN",'Nod')
            kaganga = kaganga.replace("dM","Md")
            kaganga = kaganga.replace("idM","Mid")
            kaganga = kaganga.replace("udM","Mud")
            kaganga = kaganga.replace("edM","Med")
            kaganga = kaganga.replace("odM","Mod")
            kaganga = kaganga.replace("Bxa","B")
            kaganga = kaganga.replace("Bxia","iB")
            kaganga = kaganga.replace("Bxua","uB")
            kaganga = kaganga.replace("Bxea","eB")
            kaganga = kaganga.replace("Bxoa","oB")
            kaganga = kaganga.replace("BF", 'FB')
            kaganga = kaganga.replace("iBF", 'FiB')
            kaganga = kaganga.replace("uBF", 'FuB')
            kaganga = kaganga.replace("eBF", 'FeB')
            kaganga = kaganga.replace("oBF", 'FoB')
            kaganga = kaganga.replace("BxK", 'BK')
            kaganga = kaganga.replace("BN",'NB')
            kaganga = kaganga.replace("iBN",'NiB')
            kaganga = kaganga.replace("uBN",'NuB')
            kaganga = kaganga.replace("eBN",'NeB')
            kaganga = kaganga.replace("oBN",'NoB')
            kaganga = kaganga.replace("BM","MB")
            kaganga = kaganga.replace("iBM","MiB")
            kaganga = kaganga.replace("uBM","MuB")
            kaganga = kaganga.replace("eBM","MeB")
            kaganga = kaganga.replace("oBM","MoB")
            kaganga = kaganga.replace("Jxa","J")
            kaganga = kaganga.replace("Jxia","iJ")
            kaganga = kaganga.replace("Jxua","uJ")
            kaganga = kaganga.replace("Jxea","eJ")
            kaganga = kaganga.replace("Jxoa","oJ")
            kaganga = kaganga.replace("JF", 'FJ')
            kaganga = kaganga.replace("iJF", 'FiJ')
            kaganga = kaganga.replace("uJF", 'FuJ')
            kaganga = kaganga.replace("eJF", 'FeJ')
            kaganga = kaganga.replace("oJF", 'FoJ')
            kaganga = kaganga.replace("JxK", 'JK')
            kaganga = kaganga.replace("JN",'NJ')
            kaganga = kaganga.replace("iJN",'NiJ')
            kaganga = kaganga.replace("uJN",'NuJ')
            kaganga = kaganga.replace("eJN",'NeJ')
            kaganga = kaganga.replace("oJN",'NoJ')
            kaganga = kaganga.replace("JM","MJ")
            kaganga = kaganga.replace("iJM","MiJ")
            kaganga = kaganga.replace("uJM","MuJ")
            kaganga = kaganga.replace("eJM","MeJ")
            kaganga = kaganga.replace("oJM","MoJ")
            kaganga = kaganga.replace("Gxa","G")
            kaganga = kaganga.replace("Gxia","iG")
            kaganga = kaganga.replace("Gxua","uG")
            kaganga = kaganga.replace("Gxea","eG")
            kaganga = kaganga.replace("Gxoa","oG")
            kaganga = kaganga.replace("GF", 'FG')
            kaganga = kaganga.replace("iGF", 'FiG')
            kaganga = kaganga.replace("uGF", 'FuG')
            kaganga = kaganga.replace("eGF", 'FeG')
            kaganga = kaganga.replace("oGF", 'FoG')
            kaganga = kaganga.replace("GxK", 'GK')
            kaganga = kaganga.replace("GN",'NG')
            kaganga = kaganga.replace("iGN",'NiG')
            kaganga = kaganga.replace("uGN",'NuG')
            kaganga = kaganga.replace("eGN",'NeG')
            kaganga = kaganga.replace("oGN",'NoG')
            kaganga = kaganga.replace("GM","MG")
            kaganga = kaganga.replace("iGM","MiG")
            kaganga = kaganga.replace("uGM","MuG")
            kaganga = kaganga.replace("eGM","MeG")
            kaganga = kaganga.replace("oGM","MoG")
            kaganga = kaganga.replace("Qxa","Q")
            kaganga = kaganga.replace("Qxia","iQ")
            kaganga = kaganga.replace("Qxua","uQ")
            kaganga = kaganga.replace("Qxea","eQ")
            kaganga = kaganga.replace("Qxoa","oQ")
            kaganga = kaganga.replace("QF", 'FQ')
            kaganga = kaganga.replace("iQF", 'FiQ')
            kaganga = kaganga.replace("uQF", 'FuQ')
            kaganga = kaganga.replace("eQF", 'FeQ')
            kaganga = kaganga.replace("oQF", 'FoQ')
            kaganga = kaganga.replace("QxK", 'QK')
            kaganga = kaganga.replace("QN",'NQ')
            kaganga = kaganga.replace("iQN",'NiQ')
            kaganga = kaganga.replace("uQN",'NuQ')
            kaganga = kaganga.replace("eQN",'NeQ')
            kaganga = kaganga.replace("oQN",'NoQ')
            kaganga = kaganga.replace("QM","MQ")
            kaganga = kaganga.replace("iQM","MiQ")
            kaganga = kaganga.replace("uQM","MuQ")
            kaganga = kaganga.replace("eQM","MeQ")
            kaganga = kaganga.replace("oQM","MoQ")
            kaganga = kaganga.replace("Cxa","C")
            kaganga = kaganga.replace("Cxia","iC")
            kaganga = kaganga.replace("Cxua","uC")
            kaganga = kaganga.replace("Cxea","eC")
            kaganga = kaganga.replace("Cxoa","oC")
            kaganga = kaganga.replace("CF", 'FC')
            kaganga = kaganga.replace("iCF", 'FiC')
            kaganga = kaganga.replace("uCF", 'FuC')
            kaganga = kaganga.replace("eCF", 'FeC')
            kaganga = kaganga.replace("oCF", 'FoC')
            kaganga = kaganga.replace("CxK", 'CK')
            kaganga = kaganga.replace("CN",'NC')
            kaganga = kaganga.replace("iCN",'NiC')
            kaganga = kaganga.replace("uCN",'NuC')
            kaganga = kaganga.replace("eCN",'NeC')
            kaganga = kaganga.replace("oCN",'NoC')
            kaganga = kaganga.replace("CM","MC")
            kaganga = kaganga.replace("iCM","MiC")
            kaganga = kaganga.replace("uCM","MuC")
            kaganga = kaganga.replace("eCM","MeC")
            kaganga = kaganga.replace("oCM","MoC")
            kaganga = kaganga.replace("Txa","T")
            kaganga = kaganga.replace("Txia","iT")
            kaganga = kaganga.replace("Txua","uT")
            kaganga = kaganga.replace("Txea","eT")
            kaganga = kaganga.replace("Txoa","oT")
            kaganga = kaganga.replace("TF", 'FT')
            kaganga = kaganga.replace("iTF", 'FiT')
            kaganga = kaganga.replace("uTF", 'FuT')
            kaganga = kaganga.replace("eTF", 'FeT')
            kaganga = kaganga.replace("oTF", 'FoT')
            kaganga = kaganga.replace("TxK", 'TK')
            kaganga = kaganga.replace("TN",'NT')
            kaganga = kaganga.replace("iTN",'NiT')
            kaganga = kaganga.replace("uTN",'NuT')
            kaganga = kaganga.replace("eTN",'NeT')
            kaganga = kaganga.replace("oTN",'NoT')
            kaganga = kaganga.replace("TM","MT")
            kaganga = kaganga.replace("iTM","MiT")
            kaganga = kaganga.replace("uTM","MuT")
            kaganga = kaganga.replace("eTM","MeT")
            kaganga = kaganga.replace("oTM","MoT")
            kaganga = kaganga.replace("Pxa","P")
            kaganga = kaganga.replace("Pxia","iP")
            kaganga = kaganga.replace("Pxua","uP")
            kaganga = kaganga.replace("Pxea","eP")
            kaganga = kaganga.replace("Pxoa","oP")
            kaganga = kaganga.replace("PF", 'FP')
            kaganga = kaganga.replace("iPF", 'FiP')
            kaganga = kaganga.replace("uPF", 'FuP')
            kaganga = kaganga.replace("ePF", 'FeP')
            kaganga = kaganga.replace("oPF", 'FoP')
            kaganga = kaganga.replace("PxK", 'PK')
            kaganga = kaganga.replace("PN",'NP')
            kaganga = kaganga.replace("iPN",'NiP')
            kaganga = kaganga.replace("uPN",'NuP')
            kaganga = kaganga.replace("ePN",'NeP')
            kaganga = kaganga.replace("oPN",'NoP')
            kaganga = kaganga.replace("PM","MP")
            kaganga = kaganga.replace("iPM","MiP")
            kaganga = kaganga.replace("uPM","MuP")
            kaganga = kaganga.replace("ePM","MeP")
            kaganga = kaganga.replace("oPM","MoP")
            kaganga = kaganga.replace("qxa","q")
            kaganga = kaganga.replace("qxia","iq")
            kaganga = kaganga.replace("qxua","uq")
            kaganga = kaganga.replace("qxea","eq")
            kaganga = kaganga.replace("qxoa","oq")
            kaganga = kaganga.replace("qF", 'Fq')
            kaganga = kaganga.replace("iqF", 'Fiq')
            kaganga = kaganga.replace("uqF", 'Fuq')
            kaganga = kaganga.replace("eqF", 'Feq')
            kaganga = kaganga.replace("oqF", 'Foq')
            kaganga = kaganga.replace("qxK", 'qK')   
            kaganga = kaganga.replace("qN",'Nq')
            kaganga = kaganga.replace("iqN",'Niq')
            kaganga = kaganga.replace("uqN",'Nuq')
            kaganga = kaganga.replace("eqN",'Neq')
            kaganga = kaganga.replace("oqN",'Noq')
            kaganga = kaganga.replace("qM","Mq")
            kaganga = kaganga.replace("iqM","Miq")
            kaganga = kaganga.replace("uqM","Muq")
            kaganga = kaganga.replace("eqM","Meq")
            kaganga = kaganga.replace("oqM","Moq")
            kaganga = kaganga.replace("Dxa","D")
            kaganga = kaganga.replace("Dxia","iD")
            kaganga = kaganga.replace("Dxua","uD")
            kaganga = kaganga.replace("Dxea","eD")
            kaganga = kaganga.replace("Dxoa","oD")
            kaganga = kaganga.replace("DF", 'FD')
            kaganga = kaganga.replace("iDF", 'FiD')
            kaganga = kaganga.replace("uDF", 'FuD')
            kaganga = kaganga.replace("eDF", 'FeD')
            kaganga = kaganga.replace("oDF", 'FoD')
            kaganga = kaganga.replace("DxK", 'DK')
            kaganga = kaganga.replace("DN",'ND')
            kaganga = kaganga.replace("iDN",'NiD')
            kaganga = kaganga.replace("uDN",'NuD')
            kaganga = kaganga.replace("eDN",'NeD')
            kaganga = kaganga.replace("oDN",'NoD')
            kaganga = kaganga.replace("DM","MD")
            kaganga = kaganga.replace("iDM","MiD")
            kaganga = kaganga.replace("uDM","MuD")
            kaganga = kaganga.replace("eDM","MeD")
            kaganga = kaganga.replace("oDM","MoD")
            kaganga = kaganga.replace("mbxa","B")
            kaganga = kaganga.replace("mbxia","iB")
            kaganga = kaganga.replace("mbxua","uB")
            kaganga = kaganga.replace("mbxea","eB")
            kaganga = kaganga.replace("mbxoa","oB")
            kaganga = kaganga.replace("BxK", 'BK')
            kaganga = kaganga.replace("BM","MB")
            kaganga = kaganga.replace("iBM","MiB")
            kaganga = kaganga.replace("uBM","MuB")
            kaganga = kaganga.replace("eBM","MeB")
            kaganga = kaganga.replace("oBM","MoB")
            kaganga = kaganga.replace("Na","n")
            kaganga = kaganga.replace("Nia","in")
            kaganga = kaganga.replace("Nua","un")
            kaganga = kaganga.replace("Nea","en")
            kaganga = kaganga.replace("Noa","on")
            kaganga = kaganga.replace("nF", 'Fn')
            kaganga = kaganga.replace("inF", 'Fin')
            kaganga = kaganga.replace("unF", 'Fun')
            kaganga = kaganga.replace("enF", 'Fen')
            kaganga = kaganga.replace("onF", 'Fon')   
            kaganga = kaganga.replace("nK", 'nK')
            kaganga = kaganga.replace("nN",'Nn')
            kaganga = kaganga.replace("inN",'Nni')
            kaganga = kaganga.replace("unN",'Nnu')
            kaganga = kaganga.replace("enN",'Nne')
            kaganga = kaganga.replace("onN",'Nno')            
            kaganga = kaganga.replace("nM","Mn")
            kaganga = kaganga.replace("inM","Min")
            kaganga = kaganga.replace("unM","Mun")
            kaganga = kaganga.replace("enM","Men")
            kaganga = kaganga.replace("onM","Mon")
            kaganga = kaganga.replace("pxa","p")
            kaganga = kaganga.replace("pxia","ip")
            kaganga = kaganga.replace("pxua","up")
            kaganga = kaganga.replace("pxea","ep")
            kaganga = kaganga.replace("pxoa","op")
            kaganga = kaganga.replace("pF", 'Fp')
            kaganga = kaganga.replace("ipF", 'Fip')
            kaganga = kaganga.replace("upF", 'Fup')
            kaganga = kaganga.replace("epF", 'Fep')
            kaganga = kaganga.replace("opF", 'Fop')
            kaganga = kaganga.replace("pxK", 'pK')
            kaganga = kaganga.replace("pN",'Np')
            kaganga = kaganga.replace("ipN",'Nip')
            kaganga = kaganga.replace("upN",'Nup')
            kaganga = kaganga.replace("epN",'Nep')
            kaganga = kaganga.replace("opN",'Nop')
            kaganga = kaganga.replace("pM","Mp")
            kaganga = kaganga.replace("ipM","Mip")
            kaganga = kaganga.replace("upM","Mup")
            kaganga = kaganga.replace("epM","Mep")
            kaganga = kaganga.replace("opM","Mop")
            kaganga = kaganga.replace("jxa","j")
            kaganga = kaganga.replace("jxia","ij")
            kaganga = kaganga.replace("jxua","uj")
            kaganga = kaganga.replace("jxea","ej")
            kaganga = kaganga.replace("jxoa","oj")
            kaganga = kaganga.replace("jF", 'Fj')
            kaganga = kaganga.replace("ijF", 'Fij')
            kaganga = kaganga.replace("ujF", 'Fuj')
            kaganga = kaganga.replace("ejF", 'Fej')
            kaganga = kaganga.replace("ojF", 'Foj')
            kaganga = kaganga.replace("jxK", 'jK')
            kaganga = kaganga.replace("jN",'N')
            kaganga = kaganga.replace("ijN",'Nij')
            kaganga = kaganga.replace("ujN",'Nuj')
            kaganga = kaganga.replace("ejN",'Nej')
            kaganga = kaganga.replace("ojN",'Noj')
            kaganga = kaganga.replace("jM","Mj")
            kaganga = kaganga.replace("ijM","Mij")
            kaganga = kaganga.replace("ujM","Muj")
            kaganga = kaganga.replace("ejM","Mej")
            kaganga = kaganga.replace("ojM","Moj")
            kaganga = kaganga.replace("nyxa","v")
            kaganga = kaganga.replace("nyxia","iv")
            kaganga = kaganga.replace("nyxua","uv")
            kaganga = kaganga.replace("nyxea","ev")
            kaganga = kaganga.replace("nyxoa","ov")
            kaganga = kaganga.replace("vF", 'Fv')
            kaganga = kaganga.replace("ivF", 'Fiv')
            kaganga = kaganga.replace("uvF", 'Fuv')
            kaganga = kaganga.replace("evF", 'Fev')
            kaganga = kaganga.replace("ovF", 'Fov')
            kaganga = kaganga.replace("vxK", 'vK')
            kaganga = kaganga.replace("vN",'Nv')
            kaganga = kaganga.replace("ivN",'Niv')
            kaganga = kaganga.replace("uvN",'Nuv')
            kaganga = kaganga.replace("evN",'Nev')
            kaganga = kaganga.replace("ovN",'Nov')
            kaganga = kaganga.replace("vM","M")
            kaganga = kaganga.replace("ivM","Miv")
            kaganga = kaganga.replace("uvM","Muv")
            kaganga = kaganga.replace("evM","Mev")
            kaganga = kaganga.replace("ovM","Mov")
            kaganga = kaganga.replace("sxa","s")
            kaganga = kaganga.replace("sxia","is")
            kaganga = kaganga.replace("sxua","us")
            kaganga = kaganga.replace("sxea","es")
            kaganga = kaganga.replace("sxoa","os")
            kaganga = kaganga.replace("sF", 'Fs')
            kaganga = kaganga.replace("isF", 'Fis')
            kaganga = kaganga.replace("usF", 'Fus')
            kaganga = kaganga.replace("esF", 'Fes')
            kaganga = kaganga.replace("osF", 'Fos')
            kaganga = kaganga.replace("sxK", 'sK')
            kaganga = kaganga.replace("sN",'Ns')
            kaganga = kaganga.replace("isN",'Nis')
            kaganga = kaganga.replace("usN",'Nus')
            kaganga = kaganga.replace("esN",'Nes')
            kaganga = kaganga.replace("osN",'Nos')
            kaganga = kaganga.replace("sM","Ms")
            kaganga = kaganga.replace("isM","Mis")
            kaganga = kaganga.replace("usM","Mus")
            kaganga = kaganga.replace("esM","Mes")
            kaganga = kaganga.replace("osM","Mos")
            kaganga = kaganga.replace("rxa","r")
            kaganga = kaganga.replace("rxia","ir")
            kaganga = kaganga.replace("rxua","ur")
            kaganga = kaganga.replace("rxea","er")
            kaganga = kaganga.replace("rxoa","or")
            kaganga = kaganga.replace("rF", 'Fr')
            kaganga = kaganga.replace("irF", 'Fir')
            kaganga = kaganga.replace("urF", 'Fur')
            kaganga = kaganga.replace("erF", 'Fer')
            kaganga = kaganga.replace("orF", 'For')
            kaganga = kaganga.replace("rxK", 'rK')
            kaganga = kaganga.replace("rN",'Nr')
            kaganga = kaganga.replace("irN",'Nir')
            kaganga = kaganga.replace("urN",'Nur')
            kaganga = kaganga.replace("erN",'Ner')
            kaganga = kaganga.replace("orN",'Nor')
            kaganga = kaganga.replace("rM","Mr")
            kaganga = kaganga.replace("irM","Mir")
            kaganga = kaganga.replace("urM","Mur")
            kaganga = kaganga.replace("erM","Mer")
            kaganga = kaganga.replace("orM","Mor")
            kaganga = kaganga.replace("lxa","l")
            kaganga = kaganga.replace("lxia","il")
            kaganga = kaganga.replace("lxua","ul")
            kaganga = kaganga.replace("lxea","el")
            kaganga = kaganga.replace("lxoa","ol")
            kaganga = kaganga.replace("lF", 'Fl')
            kaganga = kaganga.replace("ilF", 'Fil')
            kaganga = kaganga.replace("ulF", 'Ful')
            kaganga = kaganga.replace("elF", 'Fel')
            kaganga = kaganga.replace("olF", 'Fol')
            kaganga = kaganga.replace("lxK", 'lK')
            kaganga = kaganga.replace("lN",'Nl')
            kaganga = kaganga.replace("ilN",'Nil')
            kaganga = kaganga.replace("ulN",'Nul')
            kaganga = kaganga.replace("elN",'Nel')
            kaganga = kaganga.replace("olN",'Nol')
            kaganga = kaganga.replace("lM","Ml")
            kaganga = kaganga.replace("ilM","Mil")
            kaganga = kaganga.replace("ulM","Mul")
            kaganga = kaganga.replace("elM","Mel")
            kaganga = kaganga.replace("olM","Mol")
            kaganga = kaganga.replace("yxa","y")
            kaganga = kaganga.replace("yxia","iy")
            kaganga = kaganga.replace("yxua","uy")
            kaganga = kaganga.replace("yxea","ey")
            kaganga = kaganga.replace("yxoa","oy")
            kaganga = kaganga.replace("yF", 'Fy')
            kaganga = kaganga.replace("iyF", 'Fiy')
            kaganga = kaganga.replace("uyF", 'Fuy')
            kaganga = kaganga.replace("eyF", 'Fey')
            kaganga = kaganga.replace("oyF", 'Foy')
            kaganga = kaganga.replace("yxK", 'yK')
            kaganga = kaganga.replace("yN",'Ny')
            kaganga = kaganga.replace("iyN",'Niy')
            kaganga = kaganga.replace("uyN",'Nuy')
            kaganga = kaganga.replace("eyN",'Ney')
            kaganga = kaganga.replace("oyN",'Noy')
            kaganga = kaganga.replace("yM","My")
            kaganga = kaganga.replace("iyM","Miy")
            kaganga = kaganga.replace("uyM","Muy")
            kaganga = kaganga.replace("eyM","Mey")
            kaganga = kaganga.replace("oyM","Moy")
            kaganga = kaganga.replace("wxa","w")
            kaganga = kaganga.replace("wxia","iw")
            kaganga = kaganga.replace("wxua","uw")
            kaganga = kaganga.replace("wxea","ew")
            kaganga = kaganga.replace("wxoa","ow")
            kaganga = kaganga.replace("wF", 'Fw')
            kaganga = kaganga.replace("iwF", 'Fiw')
            kaganga = kaganga.replace("uwF", 'Fuw')
            kaganga = kaganga.replace("ewF", 'Few')
            kaganga = kaganga.replace("owF", 'Fow')
            kaganga = kaganga.replace("wxK", 'wK')
            kaganga = kaganga.replace("wN",'Nw')
            kaganga = kaganga.replace("iwN",'Niw')
            kaganga = kaganga.replace("uwN",'Nuw')
            kaganga = kaganga.replace("ewN",'New')
            kaganga = kaganga.replace("owN",'Now')
            kaganga = kaganga.replace("wM","Mw")
            kaganga = kaganga.replace("iwM","Miw")
            kaganga = kaganga.replace("uwM","Muw")
            kaganga = kaganga.replace("ewM","Mew")
            kaganga = kaganga.replace("owM","Mow")
            kaganga = kaganga.replace("hxa","h")
            kaganga = kaganga.replace("hxia","ih")
            kaganga = kaganga.replace("hxua","uh")
            kaganga = kaganga.replace("hxea","eh")
            kaganga = kaganga.replace("hxoa","oh")
            kaganga = kaganga.replace("hF", 'Fh')
            kaganga = kaganga.replace("ihF", 'Fih')
            kaganga = kaganga.replace("uhF", 'Fuh')
            kaganga = kaganga.replace("ehF", 'Feh')
            kaganga = kaganga.replace("ohF", 'Foh')
            kaganga = kaganga.replace("hxK", 'hK')
            kaganga = kaganga.replace("hN",'Nh')
            kaganga = kaganga.replace("ihN",'Nih')
            kaganga = kaganga.replace("uhN",'Nuh')
            kaganga = kaganga.replace("ehN",'Neh')
            kaganga = kaganga.replace("ohN",'Noh')
            kaganga = kaganga.replace("hM","Mh")
            kaganga = kaganga.replace("ihM","Mih")
            kaganga = kaganga.replace("uhM","Muh")
            kaganga = kaganga.replace("ehM","Meh")
            kaganga = kaganga.replace("ohM","Moh")
            kaganga = kaganga.replace("kxa","k")
            kaganga = kaganga.replace("kxia","ik")
            kaganga = kaganga.replace("kxua","uk")
            kaganga = kaganga.replace("kxea","ek")
            kaganga = kaganga.replace("kxoa","ok")
            kaganga = kaganga.replace("kF", 'Fk')
            kaganga = kaganga.replace("ikF", 'Fik')
            kaganga = kaganga.replace("ukF", 'Fuk')
            kaganga = kaganga.replace("ekF", 'Fek')
            kaganga = kaganga.replace("okF", 'Fok')
            kaganga = kaganga.replace("kxK", 'kK')
            kaganga = kaganga.replace("kN",'Nk')
            kaganga = kaganga.replace("ikN",'Nik')
            kaganga = kaganga.replace("ukN",'Nuk')
            kaganga = kaganga.replace("ekN",'Nek')
            kaganga = kaganga.replace("okN",'Nok')
            kaganga = kaganga.replace("kM","Mk")
            kaganga = kaganga.replace("ikM","Mik")
            kaganga = kaganga.replace("ukM","Muk")
            kaganga = kaganga.replace("ekM","Mek")
            kaganga = kaganga.replace("okM","Mok")
            kaganga = kaganga.replace("gxa","g")
            kaganga = kaganga.replace("gxia","ig")
            kaganga = kaganga.replace("gxua","ug")
            kaganga = kaganga.replace("gxea","eg")
            kaganga = kaganga.replace("gxoa","og")
            kaganga = kaganga.replace("gF", 'Fg')
            kaganga = kaganga.replace("igF", 'Fig')
            kaganga = kaganga.replace("ugF", 'Fug')
            kaganga = kaganga.replace("egF", 'Feg')
            kaganga = kaganga.replace("ogF", 'Fog')
            kaganga = kaganga.replace("gxK", 'gK')
            kaganga = kaganga.replace("gN",'N')
            kaganga = kaganga.replace("igN",'Ngi')
            kaganga = kaganga.replace("ugN",'Ngu')
            kaganga = kaganga.replace("egN",'Nge')
            kaganga = kaganga.replace("ogN",'Ngo')
            kaganga = kaganga.replace("gM","Mg")
            kaganga = kaganga.replace("igM","Mig")
            kaganga = kaganga.replace("ugM","Mug")
            kaganga = kaganga.replace("egM","Meg")
            kaganga = kaganga.replace("ogM","Mog")

            if not a == "Arti Muncul Disini" and not "maaf mungkin" in a:
                self.rlabel.text = kaganga
            else:
                self.rlabel.text = "kgf"
'''APP'''
class KamusBahasaRejang(App):
    def build(self):
        self.icon = 'aset/a.png'
        Config.set('graphics', 'resizable', True)

        return Kamus()
'''run'''
KamusBahasaRejang().run()